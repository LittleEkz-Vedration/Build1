// lib/features/custom_theme/custom_theme_page.dart
// Halaman pengaturan Custom Theme

import 'dart:io';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'app_theme_config.dart';
import 'app_theme_controller.dart';
import 'app_theme_presets.dart';

class CustomThemePage extends StatefulWidget {
  const CustomThemePage({super.key});

  @override
  State<CustomThemePage> createState() => _CustomThemePageState();
}

class _CustomThemePageState extends State<CustomThemePage>
    with TickerProviderStateMixin {
  late TabController _tabController;
  bool _isPickingMedia = false;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final ctrl = context.watch<AppThemeController>();
    final cfg = ctrl.config;
    final isNeoBrut = cfg.preset == ThemePreset.neobrutalism;

    return Scaffold(
      backgroundColor: isNeoBrut ? const Color(0xFFF5F0E8) : const Color(0xFF050810),
      body: Stack(
        children: [
          // Background warna sesuai preset
          Positioned.fill(child: _buildPageBackground(cfg)),

          SafeArea(
            child: Column(
              children: [
                _buildHeader(context, cfg),
                _buildTabBar(cfg),
                Expanded(
                  child: TabBarView(
                    controller: _tabController,
                    children: [
                      _PresetTab(isPickingMedia: _isPickingMedia),
                      _BackgroundTab(
                        onPickingMedia: (v) => setState(() => _isPickingMedia = v),
                      ),
                      _PayloadTab(),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPageBackground(AppThemeConfig cfg) {
    if (cfg.preset == ThemePreset.neobrutalism) {
      return Container(color: const Color(0xFFF5F0E8));
    } else if (cfg.preset == ThemePreset.spacePurple) {
      return Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [Color(0xFF0D0520), Color(0xFF1A0A3D), Color(0xFF0D0520)],
          ),
        ),
      );
    } else {
      return Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [Color(0xFF0D1B2A), Color(0xFF050810)],
          ),
        ),
      );
    }
  }

  Widget _buildHeader(BuildContext context, AppThemeConfig cfg) {
    final isNeoBrut = cfg.preset == ThemePreset.neobrutalism;
    final textColor = isNeoBrut ? const Color(0xFF0A0A0A) : const Color(0xFFEEF2FF);
    final accent = cfg.accentColor;

    return Container(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
      child: Row(
        children: [
          IconButton(
            icon: Icon(Icons.arrow_back_rounded, color: isNeoBrut ? Colors.black : accent),
            onPressed: () => Navigator.pop(context),
          ),
          const SizedBox(width: 4),
          Icon(Icons.palette_rounded, color: accent, size: 22),
          const SizedBox(width: 10),
          Text(
            'CUSTOM THEME',
            style: TextStyle(
              color: textColor,
              fontSize: 18,
              fontWeight: FontWeight.bold,
              letterSpacing: 1.5,
              fontFamily: 'Debrosee',
            ),
          ),
          const Spacer(),
          _buildActivePresetBadge(cfg),
        ],
      ),
    );
  }

  Widget _buildActivePresetBadge(AppThemeConfig cfg) {
    final isNeoBrut = cfg.preset == ThemePreset.neobrutalism;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
        color: cfg.accentColor.withOpacity(0.15),
        borderRadius: BorderRadius.circular(isNeoBrut ? 0 : 20),
        border: Border.all(
          color: isNeoBrut ? Colors.black : cfg.accentColor.withOpacity(0.5),
          width: isNeoBrut ? 2 : 1,
        ),
        boxShadow: isNeoBrut
            ? [const BoxShadow(color: Colors.black, offset: Offset(2, 2), blurRadius: 0)]
            : [],
      ),
      child: Text(
        cfg.presetName.toUpperCase(),
        style: TextStyle(
          color: isNeoBrut ? Colors.black : cfg.accentColor,
          fontSize: 10,
          fontWeight: FontWeight.bold,
          letterSpacing: 1.0,
        ),
      ),
    );
  }

  Widget _buildTabBar(AppThemeConfig cfg) {
    final isNeoBrut = cfg.preset == ThemePreset.neobrutalism;
    final textColor = isNeoBrut ? Colors.black : const Color(0xFFEEF2FF);

    return Container(
      margin: const EdgeInsets.fromLTRB(16, 12, 16, 0),
      decoration: BoxDecoration(
        color: isNeoBrut
            ? Colors.white
            : Colors.white.withOpacity(0.05),
        borderRadius: BorderRadius.circular(isNeoBrut ? 0 : 16),
        border: Border.all(
          color: isNeoBrut ? Colors.black : cfg.accentColor.withOpacity(0.2),
          width: isNeoBrut ? 2 : 1,
        ),
        boxShadow: isNeoBrut
            ? [const BoxShadow(color: Colors.black, offset: Offset(3, 3), blurRadius: 0)]
            : [],
      ),
      child: TabBar(
        controller: _tabController,
        labelColor: isNeoBrut ? cfg.accentColor : cfg.accentColor,
        unselectedLabelColor: isNeoBrut ? Colors.black54 : const Color(0xFF8B9BBE),
        indicatorColor: cfg.accentColor,
        indicatorSize: TabBarIndicatorSize.label,
        dividerColor: Colors.transparent,
        labelStyle: const TextStyle(fontSize: 11, fontWeight: FontWeight.bold, letterSpacing: 0.5),
        tabs: const [
          Tab(icon: Icon(Icons.style_rounded, size: 18), text: 'Preset'),
          Tab(icon: Icon(Icons.image_rounded, size: 18), text: 'Background'),
          Tab(icon: Icon(Icons.color_lens_rounded, size: 18), text: 'Payload'),
        ],
      ),
    );
  }
}

// ─── TAB PRESET ─────────────────────────────────────────────────────────────

class _PresetTab extends StatelessWidget {
  final bool isPickingMedia;
  const _PresetTab({required this.isPickingMedia});

  @override
  Widget build(BuildContext context) {
    final ctrl = context.watch<AppThemeController>();
    final cfg = ctrl.config;
    final isNeoBrut = cfg.preset == ThemePreset.neobrutalism;

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        _sectionTitle('PILIH PRESET TEMA', cfg),
        const SizedBox(height: 12),
        ...AppThemePresets.all.map((preset) => _PresetCard(
          preset: preset,
          isActive: cfg.preset == preset.preset,
          onTap: () async {
            await ctrl.applyPreset(preset.preset);
            if (context.mounted) {
              _showSnack(context, '✨ Tema ${preset.presetName} diterapkan!', cfg.accentColor);
            }
          },
        )),
        const SizedBox(height: 20),
        _sectionTitle('RESET SEMUA', cfg),
        const SizedBox(height: 12),
        _ResetButton(
          label: 'Reset ke Original',
          icon: Icons.restore_rounded,
          config: cfg,
          onTap: () async {
            await ctrl.resetAll();
            if (context.mounted) {
              _showSnack(context, '🔄 Tema dikembalikan ke Original', const Color(0xFF00D4FF));
            }
          },
        ),
      ],
    );
  }
}

class _PresetCard extends StatelessWidget {
  final AppThemeConfig preset;
  final bool isActive;
  final VoidCallback onTap;

  const _PresetCard({required this.preset, required this.isActive, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final isNeoBrut = preset.preset == ThemePreset.neobrutalism;
    final isSpace = preset.preset == ThemePreset.spacePurple;

    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 250),
        margin: const EdgeInsets.only(bottom: 12),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: isNeoBrut ? Colors.white : preset.cardColor,
          borderRadius: BorderRadius.circular(isNeoBrut ? 0 : 16),
          border: Border.all(
            color: isActive
                ? preset.accentColor
                : isNeoBrut
                    ? Colors.black
                    : preset.cardBorder,
            width: isActive ? (isNeoBrut ? 3 : 2) : (isNeoBrut ? 2 : 1),
          ),
          boxShadow: isNeoBrut
              ? [
                  BoxShadow(
                    color: isActive ? preset.accentColor : Colors.black,
                    offset: const Offset(4, 4),
                    blurRadius: 0,
                  )
                ]
              : isActive
                  ? [BoxShadow(color: preset.accentColor.withOpacity(0.35), blurRadius: 20, spreadRadius: 2)]
                  : [],
        ),
        child: Row(
          children: [
            // Preview warna preset
            Container(
              width: 52,
              height: 52,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [preset.accentColor, preset.accentSoft],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(isNeoBrut ? 0 : 12),
                border: Border.all(
                  color: isNeoBrut ? Colors.black : Colors.white.withOpacity(0.2),
                  width: isNeoBrut ? 2 : 1,
                ),
              ),
              child: Icon(
                _presetIcon(preset.preset),
                color: Colors.white,
                size: 24,
              ),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    preset.presetName.toUpperCase(),
                    style: TextStyle(
                      color: isNeoBrut ? Colors.black : preset.textPrimary,
                      fontSize: 15,
                      fontWeight: FontWeight.bold,
                      letterSpacing: 0.8,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    _presetDescription(preset.preset),
                    style: TextStyle(
                      color: isNeoBrut ? Colors.black54 : preset.textSecondary,
                      fontSize: 12,
                    ),
                  ),
                  const SizedBox(height: 8),
                  // Swatch palet warna
                  Row(
                    children: [
                      _colorSwatch(preset.accentColor, isNeoBrut),
                      const SizedBox(width: 4),
                      _colorSwatch(preset.payloadPrimary, isNeoBrut),
                      const SizedBox(width: 4),
                      _colorSwatch(preset.backgroundColor, isNeoBrut),
                      const SizedBox(width: 4),
                      _colorSwatch(preset.textPrimary, isNeoBrut),
                    ],
                  ),
                ],
              ),
            ),
            if (isActive)
              Container(
                padding: const EdgeInsets.all(6),
                decoration: BoxDecoration(
                  color: preset.accentColor,
                  shape: isNeoBrut ? BoxShape.rectangle : BoxShape.circle,
                ),
                child: const Icon(Icons.check, color: Colors.white, size: 14),
              ),
          ],
        ),
      ),
    );
  }

  Widget _colorSwatch(Color color, bool isNeoBrut) {
    return Container(
      width: 16,
      height: 16,
      decoration: BoxDecoration(
        color: color,
        borderRadius: BorderRadius.circular(isNeoBrut ? 0 : 4),
        border: Border.all(color: Colors.black.withOpacity(0.2)),
      ),
    );
  }

  IconData _presetIcon(ThemePreset p) {
    switch (p) {
      case ThemePreset.original:
        return Icons.home_rounded;
      case ThemePreset.neobrutalism:
        return Icons.grid_on_rounded;
      case ThemePreset.spacePurple:
        return Icons.auto_awesome_rounded;
    }
  }

  String _presetDescription(ThemePreset p) {
    switch (p) {
      case ThemePreset.original:
        return 'Tampilan bawaan Developer — Cyan & Midnight Blue';
      case ThemePreset.neobrutalism:
        return 'Bold, tegas, kontras tinggi — Gaya Neo-Brutalism';
      case ThemePreset.spacePurple:
        return 'Elegan galaksi — Ungu premium & lavender';
    }
  }
}

// ─── TAB BACKGROUND ──────────────────────────────────────────────────────────

class _BackgroundTab extends StatelessWidget {
  final ValueChanged<bool> onPickingMedia;
  const _BackgroundTab({required this.onPickingMedia});

  @override
  Widget build(BuildContext context) {
    final ctrl = context.watch<AppThemeController>();
    final cfg = ctrl.config;
    final isNeoBrut = cfg.preset == ThemePreset.neobrutalism;

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        _sectionTitle('BACKGROUND GALERI', cfg),
        const SizedBox(height: 12),

        // Pratinjau background aktif
        _BackgroundPreview(config: cfg),
        const SizedBox(height: 16),

        // Tombol pilih dari galeri
        _MediaPickerButton(
          icon: Icons.photo_rounded,
          label: 'Pilih Gambar dari Galeri',
          subtitle: 'PNG, JPG, JPEG',
          color: cfg.accentColor,
          isNeoBrut: isNeoBrut,
          onTap: () => _pickImage(context, ctrl),
        ),
        const SizedBox(height: 10),
        _MediaPickerButton(
          icon: Icons.videocam_rounded,
          label: 'Pilih Video dari Galeri',
          subtitle: 'MP4, MOV — diputar otomatis',
          color: cfg.payloadPrimary,
          isNeoBrut: isNeoBrut,
          onTap: () => _pickVideo(context, ctrl),
        ),
        const SizedBox(height: 16),
        _ResetButton(
          label: 'Reset Background ke Default',
          icon: Icons.image_not_supported_rounded,
          config: cfg,
          onTap: () async {
            await ctrl.resetBackground();
            if (context.mounted) {
              _showSnack(context, '🔄 Background direset ke default preset', cfg.accentColor);
            }
          },
        ),

        // Info background aset developer
        const SizedBox(height: 20),
        _sectionTitle('BACKGROUND PRESET DEVELOPER', cfg),
        const SizedBox(height: 8),
        _InfoCard(
          text: 'Background preset developer akan dimuat dari:\n'
              '• assets/themes/neobrutalism/background.png\n'
              '• assets/themes/space_purple/background.png\n\n'
              'Tambahkan file gambar/video ke folder tersebut untuk mengaktifkan background preset.',
          config: cfg,
        ),
      ],
    );
  }

  Future<void> _pickImage(BuildContext context, AppThemeController ctrl) async {
    try {
      final picker = ImagePicker();
      final picked = await picker.pickImage(source: ImageSource.gallery);
      if (picked == null) return;

      // Salin ke direktori aplikasi agar path persisten
      final appDir = await getApplicationDocumentsDirectory();
      final destPath = '${appDir.path}/custom_bg_${DateTime.now().millisecondsSinceEpoch}.jpg';
      await File(picked.path).copy(destPath);

      await ctrl.setGalleryBackground(destPath, false);
      if (context.mounted) {
        _showSnack(context, '🖼️ Background gambar diterapkan!', ctrl.config.accentColor);
      }
    } catch (e) {
      if (context.mounted) {
        _showSnack(context, '⚠️ Gagal memuat gambar: $e', Colors.redAccent);
      }
    }
  }

  Future<void> _pickVideo(BuildContext context, AppThemeController ctrl) async {
    try {
      final picker = ImagePicker();
      final picked = await picker.pickVideo(source: ImageSource.gallery);
      if (picked == null) return;

      // Salin ke direktori aplikasi
      final appDir = await getApplicationDocumentsDirectory();
      final destPath = '${appDir.path}/custom_bg_${DateTime.now().millisecondsSinceEpoch}.mp4';
      await File(picked.path).copy(destPath);

      await ctrl.setGalleryBackground(destPath, true);
      if (context.mounted) {
        _showSnack(context, '🎬 Background video diterapkan!', ctrl.config.accentColor);
      }
    } catch (e) {
      if (context.mounted) {
        _showSnack(context, '⚠️ Gagal memuat video: $e', Colors.redAccent);
      }
    }
  }
}

class _BackgroundPreview extends StatelessWidget {
  final AppThemeConfig config;
  const _BackgroundPreview({required this.config});

  @override
  Widget build(BuildContext context) {
    final isNeoBrut = config.preset == ThemePreset.neobrutalism;
    final hasGallery = config.backgroundType == BackgroundType.galleryImage ||
        config.backgroundType == BackgroundType.galleryVideo;
    final hasAsset = config.backgroundType == BackgroundType.assetImage;

    return Container(
      height: 140,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(isNeoBrut ? 0 : 16),
        border: Border.all(
          color: isNeoBrut ? Colors.black : config.cardBorder,
          width: isNeoBrut ? 2 : 1,
        ),
        boxShadow: isNeoBrut
            ? [const BoxShadow(color: Colors.black, offset: Offset(3, 3), blurRadius: 0)]
            : [BoxShadow(color: config.accentColor.withOpacity(0.15), blurRadius: 12)],
      ),
      clipBehavior: Clip.antiAlias,
      child: Stack(
        fit: StackFit.expand,
        children: [
          if (hasGallery && config.backgroundGalleryPath != null &&
              File(config.backgroundGalleryPath!).existsSync() &&
              config.backgroundType == BackgroundType.galleryImage)
            Image.file(File(config.backgroundGalleryPath!), fit: BoxFit.cover)
          else if (hasAsset && config.backgroundAssetPath != null)
            Image.asset(config.backgroundAssetPath!, fit: BoxFit.cover,
                errorBuilder: (_, __, ___) => _buildPlaceholder())
          else
            _buildPlaceholder(),
          // Label status
          Positioned(
            bottom: 8, left: 8,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
              decoration: BoxDecoration(
                color: Colors.black.withOpacity(0.6),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Text(
                _backgroundLabel(),
                style: const TextStyle(color: Colors.white, fontSize: 10),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPlaceholder() {
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [config.backgroundColor, config.surfaceColor],
        ),
      ),
      child: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.image_outlined, color: config.textSecondary, size: 32),
            const SizedBox(height: 6),
            Text('Belum ada background', style: TextStyle(color: config.textSecondary, fontSize: 12)),
          ],
        ),
      ),
    );
  }

  String _backgroundLabel() {
    switch (config.backgroundType) {
      case BackgroundType.galleryImage: return '📸 Galeri — Gambar';
      case BackgroundType.galleryVideo: return '🎬 Galeri — Video';
      case BackgroundType.assetImage: return '🖼️ Preset Developer';
      case BackgroundType.assetVideo: return '🎥 Video Developer';
      case BackgroundType.none: return '🎨 Warna Preset';
      default: return 'Default';
    }
  }
}

class _MediaPickerButton extends StatelessWidget {
  final IconData icon;
  final String label;
  final String subtitle;
  final Color color;
  final bool isNeoBrut;
  final VoidCallback onTap;

  const _MediaPickerButton({
    required this.icon, required this.label, required this.subtitle,
    required this.color, required this.isNeoBrut, required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: isNeoBrut ? Colors.white : color.withOpacity(0.08),
          borderRadius: BorderRadius.circular(isNeoBrut ? 0 : 14),
          border: Border.all(
            color: isNeoBrut ? Colors.black : color.withOpacity(0.35),
            width: isNeoBrut ? 2 : 1,
          ),
          boxShadow: isNeoBrut
              ? [const BoxShadow(color: Colors.black, offset: Offset(3, 3), blurRadius: 0)]
              : [],
        ),
        child: Row(
          children: [
            Container(
              width: 40, height: 40,
              decoration: BoxDecoration(
                color: color.withOpacity(0.15),
                borderRadius: BorderRadius.circular(isNeoBrut ? 0 : 10),
                border: isNeoBrut ? Border.all(color: Colors.black, width: 2) : null,
              ),
              child: Icon(icon, color: color, size: 20),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(label, style: TextStyle(
                    color: isNeoBrut ? Colors.black : const Color(0xFFEEF2FF),
                    fontWeight: FontWeight.bold, fontSize: 13,
                  )),
                  Text(subtitle, style: TextStyle(
                    color: isNeoBrut ? Colors.black54 : const Color(0xFF8B9BBE),
                    fontSize: 11,
                  )),
                ],
              ),
            ),
            Icon(Icons.arrow_forward_ios_rounded,
              color: isNeoBrut ? Colors.black : color, size: 14),
          ],
        ),
      ),
    );
  }
}

// ─── TAB PAYLOAD ─────────────────────────────────────────────────────────────

class _PayloadTab extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final ctrl = context.watch<AppThemeController>();
    final cfg = ctrl.config;
    final isNeoBrut = cfg.preset == ThemePreset.neobrutalism;

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        _sectionTitle('WARNA PAYLOAD AKTIF', cfg),
        const SizedBox(height: 8),
        _ActivePayloadPreview(config: cfg),
        const SizedBox(height: 16),
        _sectionTitle('PALET PREMIUM', cfg),
        const SizedBox(height: 12),
        ...PayloadColorPalette.premiumPalettes.map((palette) =>
          _PayloadPaletteCard(
            palette: palette,
            config: cfg,
            isActive: cfg.customPayloadPrimary == palette.primary,
            onTap: () async {
              await ctrl.setCustomPayloadColor(palette.primary, palette.secondary);
              if (context.mounted) {
                _showSnack(context, '🎨 Payload ${palette.name} diterapkan!', palette.primary);
              }
            },
          ),
        ),
        const SizedBox(height: 16),
        _ResetButton(
          label: 'Reset ke Warna Payload Default Preset',
          icon: Icons.refresh_rounded,
          config: cfg,
          onTap: () async {
            await ctrl.resetPayloadColor();
            if (context.mounted) {
              _showSnack(context, '🔄 Warna payload direset ke default', cfg.accentColor);
            }
          },
        ),
        const SizedBox(height: 10),
        _InfoCard(
          text: 'Warna payload custom bisa digunakan bersama semua preset tema. '
              'Mengganti preset tidak akan menghapus warna payload custom kamu.',
          config: cfg,
        ),
      ],
    );
  }
}

class _ActivePayloadPreview extends StatelessWidget {
  final AppThemeConfig config;
  const _ActivePayloadPreview({required this.config});

  @override
  Widget build(BuildContext context) {
    final isNeoBrut = config.preset == ThemePreset.neobrutalism;
    final primary = config.activePayloadPrimary;
    final secondary = config.activePayloadSecondary;
    final hasCustom = config.customPayloadPrimary != null;

    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: isNeoBrut ? Colors.white : config.cardColor,
        borderRadius: BorderRadius.circular(isNeoBrut ? 0 : 14),
        border: Border.all(
          color: isNeoBrut ? Colors.black : primary.withOpacity(0.4),
          width: isNeoBrut ? 2 : 1,
        ),
        boxShadow: isNeoBrut
            ? [const BoxShadow(color: Colors.black, offset: Offset(3, 3), blurRadius: 0)]
            : [BoxShadow(color: primary.withOpacity(0.2), blurRadius: 12)],
      ),
      child: Row(
        children: [
          Container(width: 36, height: 36,
            decoration: BoxDecoration(
              gradient: LinearGradient(colors: [primary, secondary]),
              borderRadius: BorderRadius.circular(isNeoBrut ? 0 : 8),
              border: isNeoBrut ? Border.all(color: Colors.black, width: 2) : null,
            ),
          ),
          const SizedBox(width: 8),
          Container(width: 20, height: 20,
            decoration: BoxDecoration(
              color: secondary,
              borderRadius: BorderRadius.circular(isNeoBrut ? 0 : 6),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                hasCustom ? 'Custom Override' : 'Default Preset',
                style: TextStyle(
                  color: isNeoBrut ? Colors.black : config.textPrimary,
                  fontWeight: FontWeight.bold, fontSize: 13,
                ),
              ),
              Text(
                '#${primary.value.toRadixString(16).toUpperCase().substring(2)}',
                style: TextStyle(
                  color: isNeoBrut ? Colors.black54 : config.textSecondary,
                  fontSize: 11, fontFamily: 'monospace',
                ),
              ),
            ],
          )),
          if (hasCustom)
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 3),
              decoration: BoxDecoration(
                color: primary.withOpacity(0.15),
                borderRadius: BorderRadius.circular(6),
                border: Border.all(color: primary.withOpacity(0.4)),
              ),
              child: Text('CUSTOM', style: TextStyle(color: primary, fontSize: 9, fontWeight: FontWeight.bold)),
            ),
        ],
      ),
    );
  }
}

class _PayloadPaletteCard extends StatelessWidget {
  final PayloadColorPalette palette;
  final AppThemeConfig config;
  final bool isActive;
  final VoidCallback onTap;

  const _PayloadPaletteCard({
    required this.palette, required this.config, required this.isActive, required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final isNeoBrut = config.preset == ThemePreset.neobrutalism;
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        margin: const EdgeInsets.only(bottom: 8),
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: isNeoBrut ? Colors.white : config.cardColor,
          borderRadius: BorderRadius.circular(isNeoBrut ? 0 : 12),
          border: Border.all(
            color: isActive
                ? palette.primary
                : isNeoBrut ? Colors.black : config.cardBorder,
            width: isActive ? (isNeoBrut ? 3 : 2) : (isNeoBrut ? 2 : 1),
          ),
          boxShadow: isNeoBrut
              ? [BoxShadow(
                  color: isActive ? palette.primary : Colors.black,
                  offset: const Offset(3, 3), blurRadius: 0,
                )]
              : isActive
                  ? [BoxShadow(color: palette.primary.withOpacity(0.3), blurRadius: 10)]
                  : [],
        ),
        child: Row(
          children: [
            Container(
              width: 32, height: 32,
              decoration: BoxDecoration(
                gradient: LinearGradient(colors: [palette.primary, palette.secondary]),
                borderRadius: BorderRadius.circular(isNeoBrut ? 0 : 8),
                border: isNeoBrut ? Border.all(color: Colors.black, width: 1) : null,
              ),
            ),
            const SizedBox(width: 12),
            Expanded(child: Text(
              palette.name,
              style: TextStyle(
                color: isNeoBrut ? Colors.black : config.textPrimary,
                fontWeight: isActive ? FontWeight.bold : FontWeight.normal,
                fontSize: 13,
              ),
            )),
            if (isActive)
              Icon(Icons.check_circle_rounded, color: palette.primary, size: 18),
          ],
        ),
      ),
    );
  }
}

// ─── SHARED WIDGETS ──────────────────────────────────────────────────────────

Widget _sectionTitle(String title, AppThemeConfig cfg) {
  final isNeoBrut = cfg.preset == ThemePreset.neobrutalism;
  return Text(
    title,
    style: TextStyle(
      color: isNeoBrut ? Colors.black : cfg.textSecondary,
      fontSize: 11,
      fontWeight: FontWeight.bold,
      letterSpacing: 1.5,
    ),
  );
}

class _ResetButton extends StatelessWidget {
  final String label;
  final IconData icon;
  final AppThemeConfig config;
  final VoidCallback onTap;

  const _ResetButton({required this.label, required this.icon, required this.config, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final isNeoBrut = config.preset == ThemePreset.neobrutalism;
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 16),
        decoration: BoxDecoration(
          color: isNeoBrut ? Colors.white : Colors.white.withOpacity(0.04),
          borderRadius: BorderRadius.circular(isNeoBrut ? 0 : 12),
          border: Border.all(
            color: isNeoBrut ? Colors.black : Colors.white.withOpacity(0.1),
            width: isNeoBrut ? 2 : 1,
          ),
          boxShadow: isNeoBrut
              ? [const BoxShadow(color: Colors.black, offset: Offset(2, 2), blurRadius: 0)]
              : [],
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, size: 16, color: isNeoBrut ? Colors.black54 : const Color(0xFF8B9BBE)),
            const SizedBox(width: 8),
            Text(label, style: TextStyle(
              color: isNeoBrut ? Colors.black54 : const Color(0xFF8B9BBE),
              fontSize: 13,
            )),
          ],
        ),
      ),
    );
  }
}

class _InfoCard extends StatelessWidget {
  final String text;
  final AppThemeConfig config;
  const _InfoCard({required this.text, required this.config});

  @override
  Widget build(BuildContext context) {
    final isNeoBrut = config.preset == ThemePreset.neobrutalism;
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: isNeoBrut ? const Color(0xFFFFF9E6) : config.accentColor.withOpacity(0.05),
        borderRadius: BorderRadius.circular(isNeoBrut ? 0 : 10),
        border: Border.all(
          color: isNeoBrut ? Colors.black : config.accentColor.withOpacity(0.2),
          width: isNeoBrut ? 2 : 1,
        ),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(Icons.info_outline_rounded, size: 14,
            color: isNeoBrut ? Colors.black54 : config.textSecondary),
          const SizedBox(width: 8),
          Expanded(child: Text(text, style: TextStyle(
            color: isNeoBrut ? Colors.black54 : config.textSecondary,
            fontSize: 11, height: 1.5,
          ))),
        ],
      ),
    );
  }
}

void _showSnack(BuildContext context, String msg, Color color) {
  ScaffoldMessenger.of(context).showSnackBar(SnackBar(
    content: Text(msg, style: const TextStyle(color: Colors.white)),
    backgroundColor: color.withOpacity(0.9),
    behavior: SnackBarBehavior.floating,
    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
    duration: const Duration(seconds: 2),
  ));
}
