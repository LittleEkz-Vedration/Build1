// lib/features/custom_theme/app_theme_presets.dart
// Definisi tiga preset tema: Original, NeoBrutalism, Space Purple

import 'dart:ui';
import 'app_theme_config.dart';

class AppThemePresets {
  AppThemePresets._();

  /// PRESET A — Original / Developer Theme
  /// Mempertahankan tampilan asli aplikasi (cyan/midnight blue)
  static const AppThemeConfig original = AppThemeConfig(
    preset: ThemePreset.original,
    presetName: 'Original',
    primaryColor: Color(0xFF050810),
    secondaryColor: Color(0xFF0D1421),
    accentColor: Color(0xFF00D4FF),
    accentSoft: Color(0xFF0099CC),
    backgroundColor: Color(0xFF050810),
    surfaceColor: Color(0xFF0D1421),
    cardColor: Color(0x1A00D4FF),
    cardBorder: Color(0x3300D4FF),
    textPrimary: Color(0xFFEEF2FF),
    textSecondary: Color(0xFF8B9BBE),
    borderColor: Color(0x3300D4FF),
    shadowColor: Color(0x4000D4FF),
    payloadPrimary: Color(0xFF00D4FF),
    payloadSecondary: Color(0xFF0099CC),
    payloadBorder: Color(0x4400D4FF),
    payloadText: Color(0xFFEEF2FF),
    backgroundType: BackgroundType.none,
  );

  /// PRESET B — NeoBrutalism Theme
  /// Warna solid, border tegas, bayangan keras, tampilan berani
  static const AppThemeConfig neobrutalism = AppThemeConfig(
    preset: ThemePreset.neobrutalism,
    presetName: 'NeoBrutalism',
    primaryColor: Color(0xFFF5F0E8),
    secondaryColor: Color(0xFFEDE5D0),
    accentColor: Color(0xFFFF3B00),
    accentSoft: Color(0xFFFF6B35),
    backgroundColor: Color(0xFFF5F0E8),
    surfaceColor: Color(0xFFEDE5D0),
    cardColor: Color(0xFFFFFFFF),
    cardBorder: Color(0xFF000000),
    textPrimary: Color(0xFF0A0A0A),
    textSecondary: Color(0xFF333333),
    borderColor: Color(0xFF000000),
    shadowColor: Color(0xFF000000),
    payloadPrimary: Color(0xFFFF3B00),
    payloadSecondary: Color(0xFFFFBF00),
    payloadBorder: Color(0xFF000000),
    payloadText: Color(0xFF0A0A0A),
    backgroundType: BackgroundType.assetImage,
    backgroundAssetPath: 'assets/themes/neobrutalism/background.png',
  );

  /// PRESET C — Space Purple / Galaxy Theme
  /// Background gelap ungu, aksen lavender, nuansa futuristik galaksi
  static const AppThemeConfig spacePurple = AppThemeConfig(
    preset: ThemePreset.spacePurple,
    presetName: 'Space Purple',
    primaryColor: Color(0xFF0D0520),
    secondaryColor: Color(0xFF160A2E),
    accentColor: Color(0xFFB87FFF),
    accentSoft: Color(0xFF9B59F5),
    backgroundColor: Color(0xFF0D0520),
    surfaceColor: Color(0xFF160A2E),
    cardColor: Color(0x22B87FFF),
    cardBorder: Color(0x44B87FFF),
    textPrimary: Color(0xFFF0EAFF),
    textSecondary: Color(0xFFAA8BCC),
    borderColor: Color(0x55B87FFF),
    shadowColor: Color(0x60B87FFF),
    payloadPrimary: Color(0xFFB87FFF),
    payloadSecondary: Color(0xFF7C3AED),
    payloadBorder: Color(0x55B87FFF),
    payloadText: Color(0xFFF0EAFF),
    backgroundType: BackgroundType.assetImage,
    backgroundAssetPath: 'assets/themes/space_purple/background.png',
  );

  static AppThemeConfig getPreset(ThemePreset preset) {
    switch (preset) {
      case ThemePreset.original:
        return original;
      case ThemePreset.neobrutalism:
        return neobrutalism;
      case ThemePreset.spacePurple:
        return spacePurple;
    }
  }

  static List<AppThemeConfig> get all => [original, neobrutalism, spacePurple];
}

/// Palet warna payload premium yang tersedia untuk customisasi
class PayloadColorPalette {
  const PayloadColorPalette({
    required this.name,
    required this.primary,
    required this.secondary,
  });

  final String name;
  final Color primary;
  final Color secondary;

  static const List<PayloadColorPalette> premiumPalettes = [
    PayloadColorPalette(name: 'Royal Purple', primary: Color(0xFF7B2FBE), secondary: Color(0xFF5A1A9A)),
    PayloadColorPalette(name: 'Midnight Blue', primary: Color(0xFF1B2A6B), secondary: Color(0xFF0D1B4A)),
    PayloadColorPalette(name: 'Emerald', primary: Color(0xFF10B981), secondary: Color(0xFF059669)),
    PayloadColorPalette(name: 'Champagne Gold', primary: Color(0xFFD4A017), secondary: Color(0xFFB8860B)),
    PayloadColorPalette(name: 'Rose Gold', primary: Color(0xFFE8A598), secondary: Color(0xFFD4857A)),
    PayloadColorPalette(name: 'Crimson', primary: Color(0xFFDC143C), secondary: Color(0xFF9B0E2A)),
    PayloadColorPalette(name: 'Ocean Teal', primary: Color(0xFF0F9B8E), secondary: Color(0xFF0A7065)),
    PayloadColorPalette(name: 'Graphite', primary: Color(0xFF4A5568), secondary: Color(0xFF2D3748)),
    PayloadColorPalette(name: 'Aurora', primary: Color(0xFF00E5A0), secondary: Color(0xFF00B377)),
    PayloadColorPalette(name: 'Cyan Ice', primary: Color(0xFF00D4FF), secondary: Color(0xFF0099CC)),
  ];
}
