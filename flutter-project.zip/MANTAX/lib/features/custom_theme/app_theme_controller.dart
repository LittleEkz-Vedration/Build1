// lib/features/custom_theme/app_theme_controller.dart
// Controller tema global — ChangeNotifier yang digunakan oleh seluruh aplikasi

import 'dart:io';
import 'dart:ui';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'app_theme_config.dart';
import 'app_theme_presets.dart';

class AppThemeController extends ChangeNotifier {
  AppThemeConfig _config = AppThemePresets.original;
  bool _isLoading = true;

  AppThemeConfig get config => _config;
  bool get isLoading => _isLoading;

  // Kunci SharedPreferences
  static const _kPreset = 'custom_theme_preset';
  static const _kBgType = 'custom_theme_bg_type';
  static const _kBgGalleryPath = 'custom_theme_bg_gallery_path';
  static const _kPayloadPrimary = 'custom_theme_payload_primary';
  static const _kPayloadSecondary = 'custom_theme_payload_secondary';

  /// Muat preferensi dari penyimpanan lokal saat startup
  Future<void> loadFromPreferences() async {
    try {
      final prefs = await SharedPreferences.getInstance();

      final presetIndex = prefs.getInt(_kPreset) ?? 0;
      final preset = ThemePreset.values[presetIndex.clamp(0, ThemePreset.values.length - 1)];
      AppThemeConfig base = AppThemePresets.getPreset(preset);

      // Pulihkan background galeri jika ada
      final bgTypeIndex = prefs.getInt(_kBgType);
      final bgGalleryPath = prefs.getString(_kBgGalleryPath);

      if (bgTypeIndex != null) {
        final bgType = BackgroundType.values[bgTypeIndex.clamp(0, BackgroundType.values.length - 1)];
        if (bgType == BackgroundType.galleryImage || bgType == BackgroundType.galleryVideo) {
          // Validasi file masih ada
          if (bgGalleryPath != null && File(bgGalleryPath).existsSync()) {
            base = base.copyWith(
              backgroundType: bgType,
              backgroundGalleryPath: bgGalleryPath,
            );
          }
          // Jika file hilang, fallback ke default preset (tidak crash)
        }
      }

      // Pulihkan warna payload custom
      final payloadPrimaryVal = prefs.getInt(_kPayloadPrimary);
      final payloadSecondaryVal = prefs.getInt(_kPayloadSecondary);
      if (payloadPrimaryVal != null) {
        base = base.copyWith(
          customPayloadPrimary: Color(payloadPrimaryVal),
          customPayloadSecondary: payloadSecondaryVal != null ? Color(payloadSecondaryVal) : null,
        );
      }

      _config = base;
    } catch (_) {
      // Fallback ke original jika konfigurasi rusak
      _config = AppThemePresets.original;
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  /// Terapkan preset tema (mempertahankan warna payload custom jika ada)
  Future<void> applyPreset(ThemePreset preset) async {
    final base = AppThemePresets.getPreset(preset);
    // Pertahankan override payload custom saat ganti preset
    _config = base.copyWith(
      customPayloadPrimary: _config.customPayloadPrimary,
      customPayloadSecondary: _config.customPayloadSecondary,
    );
    notifyListeners();
    await _saveToPreferences();
  }

  /// Terapkan preset penuh (reset semua termasuk payload custom)
  Future<void> applyPresetFull(ThemePreset preset) async {
    _config = AppThemePresets.getPreset(preset);
    notifyListeners();
    await _saveToPreferences();
  }

  /// Set background dari galeri perangkat
  Future<void> setGalleryBackground(String path, bool isVideo) async {
    _config = _config.copyWith(
      backgroundType: isVideo ? BackgroundType.galleryVideo : BackgroundType.galleryImage,
      backgroundGalleryPath: path,
    );
    notifyListeners();
    await _saveToPreferences();
  }

  /// Reset background ke default preset
  Future<void> resetBackground() async {
    final presetDefault = AppThemePresets.getPreset(_config.preset);
    _config = _config.copyWith(
      backgroundType: presetDefault.backgroundType,
      backgroundAssetPath: presetDefault.backgroundAssetPath,
      clearGalleryBackground: true,
    );
    notifyListeners();
    await _saveToPreferences();
  }

  /// Set warna payload custom
  Future<void> setCustomPayloadColor(Color primary, Color secondary) async {
    _config = _config.copyWith(
      customPayloadPrimary: primary,
      customPayloadSecondary: secondary,
    );
    notifyListeners();
    await _saveToPreferences();
  }

  /// Reset warna payload ke default preset
  Future<void> resetPayloadColor() async {
    _config = _config.copyWith(clearCustomPayload: true);
    notifyListeners();
    await _saveToPreferences();
  }

  /// Reset seluruh tema ke Original
  Future<void> resetAll() async {
    _config = AppThemePresets.original;
    notifyListeners();
    await _saveToPreferences();
  }

  Future<void> _saveToPreferences() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setInt(_kPreset, _config.preset.index);
      await prefs.setInt(_kBgType, _config.backgroundType.index);
      if (_config.backgroundGalleryPath != null) {
        await prefs.setString(_kBgGalleryPath, _config.backgroundGalleryPath!);
      } else {
        await prefs.remove(_kBgGalleryPath);
      }
      if (_config.customPayloadPrimary != null) {
        await prefs.setInt(_kPayloadPrimary, _config.customPayloadPrimary!.value);
      } else {
        await prefs.remove(_kPayloadPrimary);
      }
      if (_config.customPayloadSecondary != null) {
        await prefs.setInt(_kPayloadSecondary, _config.customPayloadSecondary!.value);
      } else {
        await prefs.remove(_kPayloadSecondary);
      }
    } catch (_) {
      // Penyimpanan gagal tidak menyebabkan crash
    }
  }
}
