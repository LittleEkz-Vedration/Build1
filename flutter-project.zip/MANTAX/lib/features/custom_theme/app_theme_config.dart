// lib/features/custom_theme/app_theme_config.dart
// Model konfigurasi tema — menyimpan semua nilai visual yang bisa dikustomisasi

import 'dart:ui';

enum ThemePreset { original, neobrutalism, spacePurple }
enum BackgroundType { none, color, assetImage, assetVideo, galleryImage, galleryVideo }

class AppThemeConfig {
  final ThemePreset preset;
  final String presetName;

  // Warna utama
  final Color primaryColor;
  final Color secondaryColor;
  final Color accentColor;
  final Color accentSoft;

  // Warna background & surface
  final Color backgroundColor;
  final Color surfaceColor;
  final Color cardColor;
  final Color cardBorder;

  // Warna teks
  final Color textPrimary;
  final Color textSecondary;

  // Warna border & shadow
  final Color borderColor;
  final Color shadowColor;

  // Warna payload (bisa di-override oleh pengguna)
  final Color payloadPrimary;
  final Color payloadSecondary;
  final Color payloadBorder;
  final Color payloadText;

  // Konfigurasi background
  final BackgroundType backgroundType;
  final String? backgroundAssetPath;   // path aset developer
  final String? backgroundGalleryPath; // path file galeri pengguna

  // Override warna payload oleh pengguna (null = gunakan default preset)
  final Color? customPayloadPrimary;
  final Color? customPayloadSecondary;

  const AppThemeConfig({
    required this.preset,
    required this.presetName,
    required this.primaryColor,
    required this.secondaryColor,
    required this.accentColor,
    required this.accentSoft,
    required this.backgroundColor,
    required this.surfaceColor,
    required this.cardColor,
    required this.cardBorder,
    required this.textPrimary,
    required this.textSecondary,
    required this.borderColor,
    required this.shadowColor,
    required this.payloadPrimary,
    required this.payloadSecondary,
    required this.payloadBorder,
    required this.payloadText,
    this.backgroundType = BackgroundType.none,
    this.backgroundAssetPath,
    this.backgroundGalleryPath,
    this.customPayloadPrimary,
    this.customPayloadSecondary,
  });

  // Warna payload yang benar-benar aktif (custom override atau default preset)
  Color get activePayloadPrimary => customPayloadPrimary ?? payloadPrimary;
  Color get activePayloadSecondary => customPayloadSecondary ?? payloadSecondary;

  AppThemeConfig copyWith({
    ThemePreset? preset,
    String? presetName,
    Color? primaryColor,
    Color? secondaryColor,
    Color? accentColor,
    Color? accentSoft,
    Color? backgroundColor,
    Color? surfaceColor,
    Color? cardColor,
    Color? cardBorder,
    Color? textPrimary,
    Color? textSecondary,
    Color? borderColor,
    Color? shadowColor,
    Color? payloadPrimary,
    Color? payloadSecondary,
    Color? payloadBorder,
    Color? payloadText,
    BackgroundType? backgroundType,
    String? backgroundAssetPath,
    String? backgroundGalleryPath,
    Color? customPayloadPrimary,
    Color? customPayloadSecondary,
    bool clearCustomPayload = false,
    bool clearGalleryBackground = false,
  }) {
    return AppThemeConfig(
      preset: preset ?? this.preset,
      presetName: presetName ?? this.presetName,
      primaryColor: primaryColor ?? this.primaryColor,
      secondaryColor: secondaryColor ?? this.secondaryColor,
      accentColor: accentColor ?? this.accentColor,
      accentSoft: accentSoft ?? this.accentSoft,
      backgroundColor: backgroundColor ?? this.backgroundColor,
      surfaceColor: surfaceColor ?? this.surfaceColor,
      cardColor: cardColor ?? this.cardColor,
      cardBorder: cardBorder ?? this.cardBorder,
      textPrimary: textPrimary ?? this.textPrimary,
      textSecondary: textSecondary ?? this.textSecondary,
      borderColor: borderColor ?? this.borderColor,
      shadowColor: shadowColor ?? this.shadowColor,
      payloadPrimary: payloadPrimary ?? this.payloadPrimary,
      payloadSecondary: payloadSecondary ?? this.payloadSecondary,
      payloadBorder: payloadBorder ?? this.payloadBorder,
      payloadText: payloadText ?? this.payloadText,
      backgroundType: backgroundType ?? this.backgroundType,
      backgroundAssetPath: backgroundAssetPath ?? this.backgroundAssetPath,
      backgroundGalleryPath: clearGalleryBackground ? null : (backgroundGalleryPath ?? this.backgroundGalleryPath),
      customPayloadPrimary: clearCustomPayload ? null : (customPayloadPrimary ?? this.customPayloadPrimary),
      customPayloadSecondary: clearCustomPayload ? null : (customPayloadSecondary ?? this.customPayloadSecondary),
    );
  }
}
