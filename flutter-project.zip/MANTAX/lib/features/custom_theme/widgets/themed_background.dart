// lib/features/custom_theme/widgets/themed_background.dart
// Widget background yang secara otomatis mengikuti tema aktif

import 'dart:io';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:video_player/video_player.dart';
import '../app_theme_config.dart';
import '../app_theme_controller.dart';
import '../app_theme_presets.dart';

class ThemedBackground extends StatelessWidget {
  final Widget child;
  final bool withOverlay;

  const ThemedBackground({
    super.key,
    required this.child,
    this.withOverlay = true,
  });

  @override
  Widget build(BuildContext context) {
    final theme = context.watch<AppThemeController>().config;

    return Stack(
      children: [
        // Layer 1: Background berdasarkan konfigurasi tema
        Positioned.fill(child: _BackgroundLayer(config: theme)),

        // Layer 2: Overlay gelap agar konten tetap terbaca
        if (withOverlay) Positioned.fill(child: _buildOverlay(theme)),

        // Layer 3: Konten aplikasi
        child,
      ],
    );
  }

  Widget _buildOverlay(AppThemeConfig theme) {
    switch (theme.preset) {
      case ThemePreset.neobrutalism:
        // NeoBrutalism: overlay sangat tipis karena bg sudah terang
        return Container(color: Colors.transparent);
      case ThemePreset.spacePurple:
        return Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [
                Colors.black.withOpacity(0.35),
                Colors.black.withOpacity(0.55),
              ],
            ),
          ),
        );
      case ThemePreset.original:
      default:
        return Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [
                Colors.black.withOpacity(0.55),
                Colors.black.withOpacity(0.75),
              ],
            ),
          ),
        );
    }
  }
}

class _BackgroundLayer extends StatefulWidget {
  final AppThemeConfig config;
  const _BackgroundLayer({required this.config});

  @override
  State<_BackgroundLayer> createState() => _BackgroundLayerState();
}

class _BackgroundLayerState extends State<_BackgroundLayer> {
  VideoPlayerController? _videoController;
  String? _currentVideoPath;
  bool _videoError = false;

  @override
  void initState() {
    super.initState();
    _initVideoIfNeeded();
  }

  @override
  void didUpdateWidget(_BackgroundLayer oldWidget) {
    super.didUpdateWidget(oldWidget);
    final newPath = _getVideoPath(widget.config);
    if (newPath != _currentVideoPath) {
      _disposeVideo();
      _initVideoIfNeeded();
    }
  }

  String? _getVideoPath(AppThemeConfig config) {
    if (config.backgroundType == BackgroundType.galleryVideo) {
      return config.backgroundGalleryPath;
    }
    // Video aset developer (jika ada di masa depan)
    if (config.backgroundType == BackgroundType.assetVideo) {
      return config.backgroundAssetPath;
    }
    return null;
  }

  void _initVideoIfNeeded() {
    final videoPath = _getVideoPath(widget.config);
    if (videoPath == null) return;

    _currentVideoPath = videoPath;
    _videoError = false;

    if (widget.config.backgroundType == BackgroundType.galleryVideo) {
      _videoController = VideoPlayerController.file(File(videoPath));
    } else {
      _videoController = VideoPlayerController.asset(videoPath);
    }

    _videoController!
        .initialize()
        .then((_) {
          if (!mounted) return;
          setState(() {
            _videoController!.setLooping(true);
            _videoController!.setVolume(0);
            _videoController!.play();
          });
        })
        .catchError((_) {
          if (!mounted) return;
          setState(() => _videoError = true);
        });
  }

  void _disposeVideo() {
    _videoController?.dispose();
    _videoController = null;
    _currentVideoPath = null;
    _videoError = false;
  }

  @override
  void dispose() {
    _disposeVideo();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final config = widget.config;

    // Background galeri video
    if (config.backgroundType == BackgroundType.galleryVideo &&
        _videoController != null &&
        _videoController!.value.isInitialized &&
        !_videoError) {
      return FittedBox(
        fit: BoxFit.cover,
        child: SizedBox(
          width: _videoController!.value.size.width,
          height: _videoController!.value.size.height,
          child: VideoPlayer(_videoController!),
        ),
      );
    }

    // Background galeri gambar
    if (config.backgroundType == BackgroundType.galleryImage &&
        config.backgroundGalleryPath != null) {
      final file = File(config.backgroundGalleryPath!);
      if (file.existsSync()) {
        return Image.file(file, fit: BoxFit.cover, width: double.infinity, height: double.infinity);
      }
      // Fallback jika file hilang
    }

    // Background aset developer (gambar)
    if (config.backgroundType == BackgroundType.assetImage &&
        config.backgroundAssetPath != null) {
      return Image.asset(
        config.backgroundAssetPath!,
        fit: BoxFit.cover,
        width: double.infinity,
        height: double.infinity,
        errorBuilder: (_, __, ___) => _buildColorBackground(config),
      );
    }

    // Fallback: background warna
    return _buildColorBackground(config);
  }

  Widget _buildColorBackground(AppThemeConfig config) {
    if (config.preset == ThemePreset.spacePurple) {
      return Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [Color(0xFF0D0520), Color(0xFF1A0A3D), Color(0xFF0D0520)],
          ),
        ),
      );
    } else if (config.preset == ThemePreset.neobrutalism) {
      return Container(
        decoration: BoxDecoration(
          color: config.backgroundColor,
          // Grid pattern khas neobrutalism
        ),
        child: CustomPaint(painter: _NeoBrutGridPainter()),
      );
    } else {
      return Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [const Color(0xFF0D1B2A), config.backgroundColor],
          ),
        ),
      );
    }
  }
}

// Painter grid NeoBrutalism
class _NeoBrutGridPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = const Color(0x15000000)
      ..strokeWidth = 1;
    const spacing = 32.0;
    for (double x = 0; x < size.width; x += spacing) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
    }
    for (double y = 0; y < size.height; y += spacing) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
