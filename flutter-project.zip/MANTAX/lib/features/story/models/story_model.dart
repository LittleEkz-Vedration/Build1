// lib/features/story/models/story_model.dart
//
// Model data Story — disimpan di Firebase Realtime Database
// Path: stories/{storyId}  (setiap story adalah node terpisah)
// Viewers: stories/{storyId}/viewers/{viewerUsername}

enum StoryType { text, photo, video }

class StoryModel {
  final String id;
  final String ownerUsername;
  final String ownerRole;
  final String? ownerProfileUrl;
  final StoryType type;
  final String? mediaUrl;      // URL file (foto/video) di Firebase Storage / server
  final String? textContent;   // Untuk story teks
  final String? caption;
  final String? bgColor;       // Hex color untuk story teks, e.g. "#1A237E"
  final int createdAt;         // Unix ms dari server
  final int expiresAt;         // createdAt + 24 jam
  final Map<String, int> viewers; // {username: timestampMs}
  final bool isProcessing;     // true saat upload belum selesai

  const StoryModel({
    required this.id,
    required this.ownerUsername,
    required this.ownerRole,
    this.ownerProfileUrl,
    required this.type,
    this.mediaUrl,
    this.textContent,
    this.caption,
    this.bgColor,
    required this.createdAt,
    required this.expiresAt,
    this.viewers = const {},
    this.isProcessing = false,
  });

  bool get isActive => DateTime.now().millisecondsSinceEpoch < expiresAt;

  int get viewerCount => viewers.length;

  bool hasViewed(String username) => viewers.containsKey(username);

  // Durasi tampil (detik): foto/teks = 5s, video tidak pakai ini
  int get displayDuration {
    switch (type) {
      case StoryType.video:
        return 30; // fallback, overridden oleh durasi video aktual
      case StoryType.photo:
        return 5;
      case StoryType.text:
        return 5;
    }
  }

  // ── Serialisasi ke Firebase ──────────────────────────────────────────────
  Map<String, dynamic> toMap() => {
        'id': id,
        'ownerUsername': ownerUsername,
        'ownerRole': ownerRole,
        if (ownerProfileUrl != null) 'ownerProfileUrl': ownerProfileUrl,
        'type': type.name,
        if (mediaUrl != null) 'mediaUrl': mediaUrl,
        if (textContent != null) 'textContent': textContent,
        if (caption != null) 'caption': caption,
        if (bgColor != null) 'bgColor': bgColor,
        'createdAt': createdAt,
        'expiresAt': expiresAt,
        'isProcessing': isProcessing,
        // viewers disimpan sebagai sub-node terpisah di Firebase
      };

  factory StoryModel.fromMap(String id, Map<dynamic, dynamic> map) {
    // Parse viewers dari sub-map Firebase
    final viewersRaw = map['viewers'];
    final Map<String, int> viewersParsed = {};
    if (viewersRaw is Map) {
      viewersRaw.forEach((k, v) {
        if (k != null) viewersParsed[k.toString()] = (v as num?)?.toInt() ?? 0;
      });
    }

    return StoryModel(
      id: id,
      ownerUsername: (map['ownerUsername'] ?? '').toString(),
      ownerRole: (map['ownerRole'] ?? '').toString(),
      ownerProfileUrl: map['ownerProfileUrl']?.toString(),
      type: StoryType.values.firstWhere(
        (e) => e.name == (map['type'] ?? 'text').toString(),
        orElse: () => StoryType.text,
      ),
      mediaUrl: map['mediaUrl']?.toString(),
      textContent: map['textContent']?.toString(),
      caption: map['caption']?.toString(),
      bgColor: map['bgColor']?.toString(),
      createdAt: (map['createdAt'] as num?)?.toInt() ?? 0,
      expiresAt: (map['expiresAt'] as num?)?.toInt() ?? 0,
      viewers: viewersParsed,
      isProcessing: (map['isProcessing'] as bool?) ?? false,
    );
  }

  StoryModel copyWith({
    String? id,
    String? ownerUsername,
    String? ownerRole,
    String? ownerProfileUrl,
    StoryType? type,
    String? mediaUrl,
    String? textContent,
    String? caption,
    String? bgColor,
    int? createdAt,
    int? expiresAt,
    Map<String, int>? viewers,
    bool? isProcessing,
  }) =>
      StoryModel(
        id: id ?? this.id,
        ownerUsername: ownerUsername ?? this.ownerUsername,
        ownerRole: ownerRole ?? this.ownerRole,
        ownerProfileUrl: ownerProfileUrl ?? this.ownerProfileUrl,
        type: type ?? this.type,
        mediaUrl: mediaUrl ?? this.mediaUrl,
        textContent: textContent ?? this.textContent,
        caption: caption ?? this.caption,
        bgColor: bgColor ?? this.bgColor,
        createdAt: createdAt ?? this.createdAt,
        expiresAt: expiresAt ?? this.expiresAt,
        viewers: viewers ?? this.viewers,
        isProcessing: isProcessing ?? this.isProcessing,
      );
}

/// Grup story per pengguna — dipakai di tray horizontal
class StoryOwnerGroup {
  final String ownerUsername;
  final String ownerRole;
  final String? ownerProfileUrl;
  final List<StoryModel> stories; // semua story aktif milik pengguna ini

  const StoryOwnerGroup({
    required this.ownerUsername,
    required this.ownerRole,
    this.ownerProfileUrl,
    required this.stories,
  });

  bool get hasUnviewed {
    final me = AppConfigRef.username ?? '';
    return stories.any((s) => !s.hasViewed(me));
  }

  StoryModel get latestStory =>
      stories.reduce((a, b) => a.createdAt > b.createdAt ? a : b);
}

// Referensi ringan ke AppConfig (menghindari circular import)
// Dashboard_page.dart mengekspos AppConfig via controller.dart
abstract class AppConfigRef {
  static String? username;
  static String? role;
  static String? profileUrl;
}
