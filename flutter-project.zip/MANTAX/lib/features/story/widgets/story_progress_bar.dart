// lib/features/story/widgets/story_progress_bar.dart
//
// Progress bar horizontal di atas Story Viewer — seperti Instagram

import 'package:flutter/material.dart';

class StoryProgressBar extends StatelessWidget {
  final int totalStories;
  final int currentIndex;
  final double progress; // 0.0 – 1.0 untuk story yang sedang aktif

  const StoryProgressBar({
    super.key,
    required this.totalStories,
    required this.currentIndex,
    required this.progress,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: List.generate(totalStories, (i) {
        double segmentValue;
        if (i < currentIndex) {
          segmentValue = 1.0; // sudah selesai
        } else if (i == currentIndex) {
          segmentValue = progress.clamp(0.0, 1.0); // sedang berjalan
        } else {
          segmentValue = 0.0; // belum
        }

        return Expanded(
          child: Padding(
            padding: EdgeInsets.symmetric(horizontal: 2),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(2),
              child: LinearProgressIndicator(
                value: segmentValue,
                minHeight: 2.5,
                backgroundColor: Colors.white.withOpacity(0.35),
                valueColor: const AlwaysStoppedAnimation<Color>(Colors.white),
              ),
            ),
          ),
        );
      }),
    );
  }
}
