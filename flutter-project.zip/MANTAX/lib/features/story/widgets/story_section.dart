// lib/features/story/widgets/story_section.dart
//
// Widget tray horizontal Story — ditempatkan TEPAT DI ATAS Container dashboard.
// Menggunakan FirebaseDatabase realtime stream dari StoryService.

import 'package:flutter/material.dart';
import '../models/story_model.dart';
import '../services/story_service.dart';
import 'story_avatar.dart';
import '../screens/story_viewer_screen.dart';
import '../screens/story_editor_screen.dart';

class StorySection extends StatefulWidget {
  final String currentUser;
  final String currentRole;
  final String? profileImagePath;

  const StorySection({
    super.key,
    required this.currentUser,
    required this.currentRole,
    this.profileImagePath,
  });

  @override
  State<StorySection> createState() => _StorySectionState();
}

class _StorySectionState extends State<StorySection> {
  final StoryService _service = StoryService.instance;

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<List<StoryModel>>(
      stream: _service.streamActiveStories(),
      builder: (context, snapshot) {
        // ── Loading awal ──────────────────────────────────────────────────
        if (snapshot.connectionState == ConnectionState.waiting) {
          return _buildShimmer();
        }

        final allStories = snapshot.data ?? [];
        final groups = _service.groupByOwner(allStories, widget.currentUser);

        // Pastikan avatar diri sendiri selalu ada
        // (meski belum punya story, untuk tombol buat story)
        StoryOwnerGroup? ownGroup;
        List<StoryOwnerGroup> othersGroups = [];

        for (final g in groups) {
          if (g.ownerUsername == widget.currentUser) {
            ownGroup = g;
          } else {
            othersGroups.add(g);
          }
        }

        // Jika tidak ada story dari diri sendiri, buat group kosong
        ownGroup ??= StoryOwnerGroup(
          ownerUsername: widget.currentUser,
          ownerRole: widget.currentRole,
          ownerProfileUrl: widget.profileImagePath,
          stories: [],
        );

        final displayGroups = [ownGroup, ...othersGroups];

        return Container(
          height: 104,
          margin: const EdgeInsets.only(bottom: 4),
          child: ListView.separated(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 12),
            itemCount: displayGroups.length,
            separatorBuilder: (_, __) => const SizedBox(width: 8),
            itemBuilder: (context, index) {
              final group = displayGroups[index];
              final isOwn = group.ownerUsername == widget.currentUser;

              return StoryAvatar(
                group: group,
                currentUser: widget.currentUser,
                isOwnAvatar: isOwn,
                onTap: () => _openViewer(context, displayGroups, index),
                onAddStory: isOwn
                    ? () => _openEditor(context)
                    : null,
              );
            },
          ),
        );
      },
    );
  }

  void _openViewer(
    BuildContext context,
    List<StoryOwnerGroup> groups,
    int startGroupIndex,
  ) {
    // Jika group yang dipilih tidak punya story, buka editor
    if (groups[startGroupIndex].stories.isEmpty) {
      _openEditor(context);
      return;
    }

    Navigator.push(
      context,
      PageRouteBuilder(
        pageBuilder: (_, __, ___) => StoryViewerScreen(
          groups: groups
              .where((g) => g.stories.isNotEmpty)
              .toList(),
          initialGroupIndex: groups[startGroupIndex].stories.isEmpty
              ? 0
              : groups
                  .where((g) => g.stories.isNotEmpty)
                  .toList()
                  .indexWhere(
                      (g) => g.ownerUsername == groups[startGroupIndex].ownerUsername),
          currentUser: widget.currentUser,
        ),
        transitionsBuilder: (_, anim, __, child) =>
            FadeTransition(opacity: anim, child: child),
        transitionDuration: const Duration(milliseconds: 200),
      ),
    );
  }

  void _openEditor(BuildContext context) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => StoryEditorScreen(
          ownerUsername: widget.currentUser,
          ownerRole: widget.currentRole,
          ownerProfileUrl: widget.profileImagePath,
        ),
      ),
    );
  }

  Widget _buildShimmer() {
    return SizedBox(
      height: 104,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 12),
        itemCount: 5,
        separatorBuilder: (_, __) => const SizedBox(width: 8),
        itemBuilder: (_, __) => Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 54,
              height: 54,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: Colors.white.withOpacity(0.10),
              ),
            ),
            const SizedBox(height: 5),
            Container(
              width: 40,
              height: 8,
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.08),
                borderRadius: BorderRadius.circular(4),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
