// lib/features/story/widgets/story_avatar.dart
//
// Avatar lingkaran di tray horizontal Story

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import '../models/story_model.dart';

class StoryAvatar extends StatelessWidget {
  final StoryOwnerGroup group;
  final String currentUser;
  final bool isOwnAvatar;
  final VoidCallback onTap;
  final VoidCallback? onAddStory; // hanya untuk avatar milik sendiri

  // Warna konsisten dengan dashboard
  static const Color _accentPurple = Color(0xFF4FC3F7);
  static const Color _accentGold = Color(0xFFA5E7FF);
  static const Color _accentPink = Color(0xFF64B5F6);
  static const Color _bloodRed = Color(0xFF00B4D8);

  const StoryAvatar({
    super.key,
    required this.group,
    required this.currentUser,
    required this.isOwnAvatar,
    required this.onTap,
    this.onAddStory,
  });

  @override
  Widget build(BuildContext context) {
    final hasUnviewed = group.hasUnviewed;
    final hasStory = group.stories.isNotEmpty;

    return GestureDetector(
      onTap: onTap,
      child: SizedBox(
        width: 72,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Stack(
              alignment: Alignment.center,
              children: [
                // Ring gradasi (aktif = warna, viewed = abu)
                if (hasStory)
                  Container(
                    width: 62,
                    height: 62,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: hasUnviewed
                          ? const LinearGradient(
                              colors: [
                                Color(0xFFE53935),
                                Color(0xFFFF6D00),
                                Color(0xFFFDD835),
                              ],
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                            )
                          : null,
                      color: hasUnviewed
                          ? null
                          : Colors.white.withOpacity(0.25),
                    ),
                  )
                else
                  // Belum ada story — ring transparan
                  Container(
                    width: 62,
                    height: 62,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      border: Border.all(
                        color: Colors.white.withOpacity(0.20),
                        width: 1.5,
                      ),
                    ),
                  ),

                // Avatar foto
                _buildAvatarPhoto(),

                // Tombol + untuk avatar milik sendiri
                if (isOwnAvatar)
                  Positioned(
                    bottom: 0,
                    right: 0,
                    child: GestureDetector(
                      onTap: onAddStory,
                      child: Container(
                        width: 22,
                        height: 22,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          gradient: const LinearGradient(
                            colors: [_bloodRed, _accentPurple],
                          ),
                          border: Border.all(color: Colors.black, width: 2),
                        ),
                        child: const Icon(
                          Icons.add,
                          color: Colors.white,
                          size: 13,
                        ),
                      ),
                    ),
                  ),
              ],
            ),
            const SizedBox(height: 5),
            // Nama pengguna
            Text(
              isOwnAvatar ? 'Kamu' : group.ownerUsername,
              style: TextStyle(
                color: Colors.white.withOpacity(0.88),
                fontSize: 10.5,
                fontWeight:
                    isOwnAvatar ? FontWeight.w700 : FontWeight.w500,
                letterSpacing: 0.2,
              ),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildAvatarPhoto() {
    final profileUrl = group.ownerProfileUrl;
    return Container(
      width: 54,
      height: 54,
      decoration: const BoxDecoration(shape: BoxShape.circle),
      child: ClipOval(
        child: profileUrl != null && profileUrl.isNotEmpty
            ? CachedNetworkImage(
                imageUrl: profileUrl,
                fit: BoxFit.cover,
                placeholder: (_, __) => _defaultAvatar(),
                errorWidget: (_, __, ___) => _defaultAvatar(),
              )
            : _defaultAvatar(),
      ),
    );
  }

  Widget _defaultAvatar() {
    // Warna avatar berdasarkan huruf pertama username
    final colors = [
      _accentPurple,
      _accentPink,
      _bloodRed,
      _accentGold,
      const Color(0xFF81C784),
      const Color(0xFFFFB74D),
    ];
    final colorIdx = group.ownerUsername.isEmpty
        ? 0
        : group.ownerUsername.codeUnitAt(0) % colors.length;

    return Container(
      color: colors[colorIdx].withOpacity(0.25),
      child: Center(
        child: Text(
          group.ownerUsername.isEmpty
              ? '?'
              : group.ownerUsername[0].toUpperCase(),
          style: TextStyle(
            color: colors[colorIdx],
            fontSize: 22,
            fontWeight: FontWeight.w700,
          ),
        ),
      ),
    );
  }
}
