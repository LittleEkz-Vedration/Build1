// lib/features/story/widgets/story_heartbeat_painter.dart
//
// Animasi garis merah menyerupai gelombang detak jantung (ECG/monitor RS)
// Ditempatkan: TEPAT DI BAWAH Story tray, TEPAT DI ATAS Container dashboard utama
// Menggunakan CustomPainter + AnimationController — tanpa package tambahan.

import 'dart:math' as math;
import 'package:flutter/material.dart';

// ─────────────────────────────────────────────────────────────────────────────
//  WIDGET PUBLIK
// ─────────────────────────────────────────────────────────────────────────────
class StoryHeartbeatLine extends StatefulWidget {
  /// Tinggi area animasi (default 28 px)
  final double height;

  /// Warna garis ECG (default merah rumah sakit)
  final Color color;

  const StoryHeartbeatLine({
    super.key,
    this.height = 28,
    this.color = const Color(0xFFE53935),
  });

  @override
  State<StoryHeartbeatLine> createState() => _StoryHeartbeatLineState();
}

class _StoryHeartbeatLineState extends State<StoryHeartbeatLine>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _anim;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1800),
    )..repeat();
    _anim = Tween<double>(begin: 0, end: 1).animate(_ctrl);
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return RepaintBoundary(
      child: SizedBox(
        width: double.infinity,
        height: widget.height,
        child: AnimatedBuilder(
          animation: _anim,
          builder: (_, __) => CustomPaint(
            painter: _HeartbeatPainter(
              progress: _anim.value,
              color: widget.color,
            ),
          ),
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
//  PAINTER
// ─────────────────────────────────────────────────────────────────────────────
class _HeartbeatPainter extends CustomPainter {
  final double progress; // 0.0 – 1.0
  final Color color;

  _HeartbeatPainter({required this.progress, required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final w = size.width;
    final h = size.height;
    final midY = h / 2;

    // Titik "kepala" gelombang bergerak dari kanan ke kiri (scroll efek)
    // progress 0→1 berarti kepala bergerak dari kiri ke kanan
    final headX = w * progress;

    final paint = Paint()
      ..color = color
      ..strokeWidth = 1.8
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round;

    final glowPaint = Paint()
      ..color = color.withOpacity(0.25)
      ..strokeWidth = 5
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 4);

    // Kita gambar gelombang ECG sebagai path segmen
    // Gelombang berulang setiap 200px lebar
    const cycleW = 200.0;

    // Hitung berapa siklus yang termuat di layar
    final path = Path();
    bool started = false;

    // Offset geser: gelombang bergerak ke kiri seiring progress
    final offset = -(progress * cycleW * 2) % cycleW;

    double x = offset - cycleW;
    while (x < w + cycleW) {
      final points = _ecgCyclePoints(x, midY, cycleW, h);
      for (int i = 0; i < points.length; i++) {
        final pt = points[i];
        if (!started) {
          path.moveTo(pt.dx, pt.dy);
          started = true;
        } else {
          path.lineTo(pt.dx, pt.dy);
        }
      }
      x += cycleW;
    }

    // Gambar glow terlebih dahulu
    canvas.drawPath(path, glowPaint);

    // Gambar garis utama (hanya sampai headX untuk efek "menulis")
    // Kita clip area di sebelah kanan headX agar terlihat "berjalan"
    canvas.save();
    canvas.clipRect(Rect.fromLTWH(0, 0, headX, h));
    canvas.drawPath(path, paint);
    canvas.restore();

    // Dot merah terang di kepala gelombang
    if (headX > 0 && headX < w) {
      // Ambil titik Y pada headX dari path
      final dotY = _getYatX(headX, offset, midY, cycleW, h);
      canvas.drawCircle(
        Offset(headX, dotY),
        3.5,
        Paint()
          ..color = Colors.white
          ..style = PaintingStyle.fill,
      );
      canvas.drawCircle(
        Offset(headX, dotY),
        5,
        Paint()
          ..color = color.withOpacity(0.6)
          ..style = PaintingStyle.fill
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 4),
      );
    }
  }

  /// Generate titik-titik gelombang ECG dalam 1 siklus mulai dari [startX]
  List<Offset> _ecgCyclePoints(
      double startX, double midY, double cycleW, double h) {
    final amp = h * 0.28; // amplitudo normal
    final spike = h * 0.46; // tinggi puncak QRS

    // Segmen ECG klasik: P, Q, R, S, T wave
    // Rasio dalam satu siklus (0–1):
    //   0.00–0.10: flat (isoelectric)
    //   0.10–0.20: P wave (gelombang kecil atas)
    //   0.20–0.30: flat
    //   0.30–0.33: Q (turun kecil)
    //   0.33–0.40: R (spike tinggi ke atas)
    //   0.40–0.43: S (turun ke bawah)
    //   0.43–0.50: kembali ke baseline
    //   0.50–0.70: flat
    //   0.70–0.90: T wave (gelombang sedang atas)
    //   0.90–1.00: flat

    final pts = <Offset>[];
    void add(double frac, double y) =>
        pts.add(Offset(startX + frac * cycleW, y));

    add(0.00, midY);
    add(0.10, midY);
    add(0.15, midY - amp * 0.4); // P peak
    add(0.20, midY);
    add(0.30, midY);
    add(0.33, midY + amp * 0.25); // Q dip
    add(0.37, midY - spike); // R spike (puncak)
    add(0.41, midY + amp * 0.35); // S dip
    add(0.46, midY);
    add(0.50, midY);
    add(0.70, midY);
    add(0.75, midY - amp * 0.55); // T peak
    add(0.80, midY - amp * 0.55);
    add(0.86, midY);
    add(1.00, midY);

    return pts;
  }

  /// Estimasi Y pada posisi X tertentu untuk titik kepala gelombang
  double _getYatX(
      double x, double offset, double midY, double cycleW, double h) {
    const amplitude = 0.28;
    // Normalisasi x ke dalam satu siklus
    final relX = ((x - offset) % cycleW + cycleW) % cycleW;
    final frac = relX / cycleW;

    // Reproduksi fungsi gelombang sederhana
    if (frac < 0.10 || frac > 0.90) return midY;
    if (frac >= 0.10 && frac <= 0.20) {
      final t = (frac - 0.10) / 0.10;
      return midY - h * amplitude * 0.4 * math.sin(t * math.pi);
    }
    if (frac >= 0.30 && frac <= 0.50) {
      final t = (frac - 0.30) / 0.20;
      // QRS complex
      if (t < 0.15) return midY + h * 0.25 * 0.28 * (t / 0.15);
      if (t < 0.35) {
        final tt = (t - 0.15) / 0.20;
        return midY - h * 0.46 * math.sin(tt * math.pi);
      }
      if (t < 0.50) return midY + h * 0.35 * 0.28 * (1 - (t - 0.35) / 0.15);
      return midY;
    }
    if (frac >= 0.70 && frac <= 0.86) {
      final t = (frac - 0.70) / 0.16;
      return midY - h * amplitude * 0.55 * math.sin(t * math.pi);
    }
    return midY;
  }

  @override
  bool shouldRepaint(_HeartbeatPainter old) =>
      old.progress != progress || old.color != color;
}
