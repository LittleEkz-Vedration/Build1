// lib/features/story/screens/story_viewer_screen.dart
//
// Story Viewer fullscreen — mirip Instagram
// - Progress bar per story di atas
// - Ketuk kanan/kiri untuk next/prev
// - Tekan tahan untuk pause timer
// - Story foto/video/teks
// - Panel viewers (swipe up) untuk pemilik story
// - Catat view ke Firebase secara otomatis

import 'dart:async';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:video_player/video_player.dart';
import '../models/story_model.dart';
import '../services/story_service.dart';
import '../widgets/story_progress_bar.dart';

class StoryViewerScreen extends StatefulWidget {
  final List<StoryOwnerGroup> groups;
  final int initialGroupIndex;
  final String currentUser;

  const StoryViewerScreen({
    super.key,
    required this.groups,
    required this.initialGroupIndex,
    required this.currentUser,
  });

  @override
  State<StoryViewerScreen> createState() => _StoryViewerScreenState();
}

class _StoryViewerScreenState extends State<StoryViewerScreen>
    with TickerProviderStateMixin {
  late int _groupIndex;
  late int _storyIndex;

  // Progress
  late AnimationController _progressCtrl;
  bool _isPaused = false;
  bool _isDisposed = false;

  // Video
  VideoPlayerController? _videoCtrl;
  bool _videoReady = false;

  // Viewers panel
  bool _showViewers = false;

  final StoryService _service = StoryService.instance;

  // ── Getters ────────────────────────────────────────────────────────────
  StoryOwnerGroup get _currentGroup => widget.groups[_groupIndex];
  StoryModel get _currentStory => _currentGroup.stories[_storyIndex];
  bool get _isOwner => _currentStory.ownerUsername == widget.currentUser;

  @override
  void initState() {
    super.initState();
    _groupIndex = widget.initialGroupIndex.clamp(0, widget.groups.length - 1);
    _storyIndex = 0;
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
    _progressCtrl = AnimationController(vsync: this);
    _loadStory();
  }

  @override
  void dispose() {
    _isDisposed = true;
    _progressCtrl.dispose();
    _videoCtrl?.dispose();
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    super.dispose();
  }

  // ─────────────────────────────────────────────────────────────────────────
  //  MUAT STORY
  // ─────────────────────────────────────────────────────────────────────────
  Future<void> _loadStory() async {
    if (_isDisposed) return;
    _videoCtrl?.dispose();
    _videoCtrl = null;
    _videoReady = false;
    _isPaused = false;
    _progressCtrl.stop();
    _progressCtrl.reset();

    final story = _currentStory;

    // Catat view
    _service.recordView(
      storyId: story.id,
      viewerUsername: widget.currentUser,
      ownerUsername: story.ownerUsername,
    );

    if (story.type == StoryType.video && story.mediaUrl != null) {
      await _initVideo(story.mediaUrl!);
    } else {
      _startTimer(Duration(seconds: story.displayDuration));
    }
  }

  Future<void> _initVideo(String url) async {
    try {
      _videoCtrl = VideoPlayerController.networkUrl(Uri.parse(url));
      await _videoCtrl!.initialize();
      if (_isDisposed) return;
      setState(() => _videoReady = true);
      _videoCtrl!.play();
      final duration =
          _videoCtrl!.value.duration.inSeconds.clamp(1, 60);
      _startTimer(Duration(seconds: duration));
    } catch (e) {
      debugPrint('[StoryViewer] Video init error: $e');
      _startTimer(const Duration(seconds: 5));
    }
  }

  void _startTimer(Duration duration) {
    if (_isDisposed) return;
    _progressCtrl.duration = duration;
    _progressCtrl.forward().then((_) {
      if (!_isDisposed && !_isPaused) _nextStory();
    });
  }

  // ─────────────────────────────────────────────────────────────────────────
  //  NAVIGASI
  // ─────────────────────────────────────────────────────────────────────────
  void _nextStory() {
    if (_isDisposed) return;
    if (_storyIndex < _currentGroup.stories.length - 1) {
      setState(() => _storyIndex++);
      _loadStory();
    } else if (_groupIndex < widget.groups.length - 1) {
      setState(() {
        _groupIndex++;
        _storyIndex = 0;
      });
      _loadStory();
    } else {
      Navigator.pop(context);
    }
  }

  void _prevStory() {
    if (_isDisposed) return;
    if (_storyIndex > 0) {
      setState(() => _storyIndex--);
      _loadStory();
    } else if (_groupIndex > 0) {
      setState(() {
        _groupIndex--;
        _storyIndex = _currentGroup.stories.length - 1;
      });
      _loadStory();
    }
  }

  void _pauseTimer() {
    _isPaused = true;
    _progressCtrl.stop();
    _videoCtrl?.pause();
  }

  void _resumeTimer() {
    _isPaused = false;
    _progressCtrl.forward();
    _videoCtrl?.play();
  }

  // ─────────────────────────────────────────────────────────────────────────
  //  BUILD
  // ─────────────────────────────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    final story = _currentStory;

    return Scaffold(
      backgroundColor: Colors.black,
      body: GestureDetector(
        onLongPressStart: (_) => _pauseTimer(),
        onLongPressEnd: (_) => _resumeTimer(),
        // Swipe up untuk panel viewers
        onVerticalDragEnd: (details) {
          if (details.primaryVelocity != null &&
              details.primaryVelocity! < -300 &&
              _isOwner) {
            setState(() => _showViewers = true);
            _pauseTimer();
          }
        },
        child: Stack(
          fit: StackFit.expand,
          children: [
            // ── KONTEN STORY ────────────────────────────────────────────
            _buildStoryContent(story),

            // ── OVERLAY GRADASI ATAS DAN BAWAH ──────────────────────────
            _buildGradientOverlay(),

            // ── HEADER: PROGRESS + INFO PEMILIK ─────────────────────────
            _buildHeader(story),

            // ── TAP AREA KIRI/KANAN ──────────────────────────────────────
            _buildTapAreas(),

            // ── CAPTION ─────────────────────────────────────────────────
            if (story.caption != null && story.caption!.isNotEmpty)
              _buildCaption(story),

            // ── PANEL VIEWERS (pemilik story) ────────────────────────────
            if (_showViewers && _isOwner) _buildViewersPanel(story),

            // ── HINT SWIPE UP (untuk pemilik) ───────────────────────────
            if (_isOwner && !_showViewers) _buildSwipeUpHint(),
          ],
        ),
      ),
    );
  }

  // ── Story Content ─────────────────────────────────────────────────────────
  Widget _buildStoryContent(StoryModel story) {
    switch (story.type) {
      case StoryType.photo:
        if (story.mediaUrl != null) {
          return CachedNetworkImage(
            imageUrl: story.mediaUrl!,
            fit: BoxFit.contain,
            placeholder: (_, __) => const Center(
              child: CircularProgressIndicator(color: Colors.white),
            ),
            errorWidget: (_, __, ___) => _errorWidget(),
          );
        }
        return _errorWidget();

      case StoryType.video:
        if (_videoReady && _videoCtrl != null) {
          return Center(
            child: AspectRatio(
              aspectRatio: _videoCtrl!.value.aspectRatio,
              child: VideoPlayer(_videoCtrl!),
            ),
          );
        }
        return const Center(
          child: CircularProgressIndicator(color: Colors.white),
        );

      case StoryType.text:
        final bg = _parseColor(story.bgColor ?? '#0D1117');
        return Container(
          color: bg,
          alignment: Alignment.center,
          padding: const EdgeInsets.symmetric(horizontal: 32),
          child: Text(
            story.textContent ?? '',
            style: const TextStyle(
              color: Colors.white,
              fontSize: 28,
              fontWeight: FontWeight.w700,
              height: 1.4,
            ),
            textAlign: TextAlign.center,
          ),
        );
    }
  }

  // ── Gradient overlay ──────────────────────────────────────────────────────
  Widget _buildGradientOverlay() {
    return Column(
      children: [
        Container(
          height: 120,
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [
                Colors.black.withOpacity(0.65),
                Colors.transparent,
              ],
            ),
          ),
        ),
        const Spacer(),
        Container(
          height: 120,
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.bottomCenter,
              end: Alignment.topCenter,
              colors: [
                Colors.black.withOpacity(0.65),
                Colors.transparent,
              ],
            ),
          ),
        ),
      ],
    );
  }

  // ── Header ────────────────────────────────────────────────────────────────
  Widget _buildHeader(StoryModel story) {
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            // Progress bar
            AnimatedBuilder(
              animation: _progressCtrl,
              builder: (_, __) => StoryProgressBar(
                totalStories: _currentGroup.stories.length,
                currentIndex: _storyIndex,
                progress: _progressCtrl.value,
              ),
            ),
            const SizedBox(height: 10),
            // Info pemilik + tombol tutup
            Row(
              children: [
                // Avatar kecil
                Container(
                  width: 36,
                  height: 36,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    border: Border.all(color: Colors.white, width: 1.5),
                  ),
                  child: ClipOval(
                    child: story.ownerProfileUrl != null
                        ? CachedNetworkImage(
                            imageUrl: story.ownerProfileUrl!,
                            fit: BoxFit.cover,
                            errorWidget: (_, __, ___) =>
                                _avatarInitial(story.ownerUsername),
                          )
                        : _avatarInitial(story.ownerUsername),
                  ),
                ),
                const SizedBox(width: 10),
                // Nama + waktu
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        story.ownerUsername,
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 13.5,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                      Text(
                        _timeAgo(story.createdAt),
                        style: TextStyle(
                          color: Colors.white.withOpacity(0.7),
                          fontSize: 11,
                        ),
                      ),
                    ],
                  ),
                ),
                // Tombol tutup
                IconButton(
                  onPressed: () => Navigator.pop(context),
                  icon: const Icon(Icons.close, color: Colors.white),
                  iconSize: 24,
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  // ── Tap areas ─────────────────────────────────────────────────────────────
  Widget _buildTapAreas() {
    return Row(
      children: [
        // Kiri → prev
        Expanded(
          flex: 1,
          child: GestureDetector(
            onTap: _prevStory,
            behavior: HitTestBehavior.translucent,
          ),
        ),
        // Kanan → next
        Expanded(
          flex: 2,
          child: GestureDetector(
            onTap: _nextStory,
            behavior: HitTestBehavior.translucent,
          ),
        ),
      ],
    );
  }

  // ── Caption ───────────────────────────────────────────────────────────────
  Widget _buildCaption(StoryModel story) {
    return Positioned(
      bottom: 40,
      left: 16,
      right: 16,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
        decoration: BoxDecoration(
          color: Colors.black.withOpacity(0.5),
          borderRadius: BorderRadius.circular(12),
        ),
        child: Text(
          story.caption!,
          style: const TextStyle(color: Colors.white, fontSize: 13),
          textAlign: TextAlign.center,
          maxLines: 3,
          overflow: TextOverflow.ellipsis,
        ),
      ),
    );
  }

  // ── Swipe up hint ─────────────────────────────────────────────────────────
  Widget _buildSwipeUpHint() {
    return Positioned(
      bottom: 16,
      left: 0,
      right: 0,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Icon(Icons.keyboard_arrow_up, color: Colors.white, size: 22),
          Text(
            'Geser untuk lihat viewers',
            style: TextStyle(
              color: Colors.white.withOpacity(0.7),
              fontSize: 11,
            ),
          ),
        ],
      ),
    );
  }

  // ── Viewers panel ─────────────────────────────────────────────────────────
  Widget _buildViewersPanel(StoryModel story) {
    return GestureDetector(
      onVerticalDragEnd: (details) {
        if (details.primaryVelocity != null &&
            details.primaryVelocity! > 300) {
          setState(() => _showViewers = false);
          _resumeTimer();
        }
      },
      child: Container(
        color: Colors.black.withOpacity(0.92),
        child: StreamBuilder<Map<String, int>>(
          stream: _service.streamViewers(story.id),
          builder: (context, snap) {
            final viewers = snap.data ?? {};
            return SafeArea(
              child: Column(
                children: [
                  // Handle bar
                  const SizedBox(height: 12),
                  Container(
                    width: 40,
                    height: 4,
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.3),
                      borderRadius: BorderRadius.circular(2),
                    ),
                  ),
                  const SizedBox(height: 16),
                  // Header
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 20),
                    child: Row(
                      children: [
                        const Icon(Icons.visibility_outlined,
                            color: Colors.white, size: 20),
                        const SizedBox(width: 8),
                        Text(
                          '${viewers.length} yang melihat',
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 15,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                        const Spacer(),
                        IconButton(
                          onPressed: () {
                            setState(() => _showViewers = false);
                            _resumeTimer();
                          },
                          icon: const Icon(Icons.close,
                              color: Colors.white, size: 20),
                        ),
                      ],
                    ),
                  ),
                  const Divider(color: Colors.white24),
                  // Daftar viewers
                  Expanded(
                    child: viewers.isEmpty
                        ? Center(
                            child: Text(
                              'Belum ada yang melihat',
                              style: TextStyle(
                                color: Colors.white.withOpacity(0.5),
                                fontSize: 13,
                              ),
                            ),
                          )
                        : ListView.builder(
                            padding:
                                const EdgeInsets.symmetric(horizontal: 16),
                            itemCount: viewers.length,
                            itemBuilder: (_, i) {
                              final entry =
                                  viewers.entries.elementAt(i);
                              return ListTile(
                                leading: CircleAvatar(
                                  backgroundColor: const Color(0xFF4FC3F7)
                                      .withOpacity(0.25),
                                  child: Text(
                                    entry.key.isEmpty
                                        ? '?'
                                        : entry.key[0].toUpperCase(),
                                    style: const TextStyle(
                                      color: Color(0xFF4FC3F7),
                                      fontWeight: FontWeight.w700,
                                    ),
                                  ),
                                ),
                                title: Text(
                                  entry.key,
                                  style: const TextStyle(
                                    color: Colors.white,
                                    fontSize: 13.5,
                                  ),
                                ),
                                subtitle: Text(
                                  _timeAgo(entry.value),
                                  style: TextStyle(
                                    color: Colors.white.withOpacity(0.5),
                                    fontSize: 11,
                                  ),
                                ),
                              );
                            },
                          ),
                  ),
                ],
              ),
            );
          },
        ),
      ),
    );
  }

  // ── Helpers ───────────────────────────────────────────────────────────────
  Widget _errorWidget() {
    return Container(
      color: Colors.black,
      child: const Center(
        child: Icon(Icons.broken_image_outlined,
            color: Colors.white54, size: 64),
      ),
    );
  }

  Widget _avatarInitial(String name) {
    return Container(
      color: const Color(0xFF4FC3F7).withOpacity(0.25),
      child: Center(
        child: Text(
          name.isEmpty ? '?' : name[0].toUpperCase(),
          style: const TextStyle(
            color: Color(0xFF4FC3F7),
            fontSize: 16,
            fontWeight: FontWeight.w700,
          ),
        ),
      ),
    );
  }

  Color _parseColor(String hex) {
    try {
      final h = hex.replaceAll('#', '');
      return Color(int.parse('FF$h', radix: 16));
    } catch (_) {
      return const Color(0xFF0D1117);
    }
  }

  String _timeAgo(int ms) {
    if (ms == 0) return '';
    final diff = DateTime.now()
        .difference(DateTime.fromMillisecondsSinceEpoch(ms));
    if (diff.inMinutes < 1) return 'Baru saja';
    if (diff.inMinutes < 60) return '${diff.inMinutes}m lalu';
    if (diff.inHours < 24) return '${diff.inHours}j lalu';
    return '${diff.inDays}h lalu';
  }
}
