// lib/features/story/screens/story_editor_screen.dart
//
// Editor Story — buat story teks, foto, atau video
// Pengguna dapat upload berkali-kali tanpa batas selama aktif

import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:video_player/video_player.dart';
import '../models/story_model.dart';
import '../services/story_service.dart';

class StoryEditorScreen extends StatefulWidget {
  final String ownerUsername;
  final String ownerRole;
  final String? ownerProfileUrl;

  const StoryEditorScreen({
    super.key,
    required this.ownerUsername,
    required this.ownerRole,
    this.ownerProfileUrl,
  });

  @override
  State<StoryEditorScreen> createState() => _StoryEditorScreenState();
}

class _StoryEditorScreenState extends State<StoryEditorScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabCtrl;
  final StoryService _service = StoryService.instance;
  final ImagePicker _picker = ImagePicker();

  // ── State teks ────────────────────────────────────────────────────────────
  final _textCtrl = TextEditingController();

  // Caption terpisah per tab agar tidak saling overwrite
  final _textCaptionCtrl = TextEditingController();
  final _photoCaptionCtrl = TextEditingController();
  final _videoCaptionCtrl = TextEditingController();

  String _selectedBg = '#0D1117';

  // ── State media ───────────────────────────────────────────────────────────
  File? _selectedFile;
  StoryType _selectedType = StoryType.photo;
  VideoPlayerController? _videoPreviewCtrl;
  bool _videoPreviewReady = false;

  // ── Upload state ──────────────────────────────────────────────────────────
  bool _isUploading = false;
  double _uploadProgress = 0;
  String _statusMsg = '';

  static const List<String> _bgColors = [
    '#0D1117', '#1A237E', '#1B5E20', '#B71C1C',
    '#4A148C', '#E65100', '#006064', '#212121',
    '#880E4F', '#1A0533',
  ];

  @override
  void initState() {
    super.initState();
    _tabCtrl = TabController(length: 3, vsync: this);
  }

  @override
  void dispose() {
    _tabCtrl.dispose();
    _textCtrl.dispose();
    _textCaptionCtrl.dispose();
    _photoCaptionCtrl.dispose();
    _videoCaptionCtrl.dispose();
    _videoPreviewCtrl?.dispose();
    super.dispose();
  }

  // ─────────────────────────────────────────────────────────────────────────
  //  PICK MEDIA
  // ─────────────────────────────────────────────────────────────────────────
  Future<void> _pickImage(ImageSource source) async {
    // Jangan buka picker saat sedang upload
    if (_isUploading) return;
    try {
      final xfile = await _picker.pickImage(
        source: source,
        maxWidth: 1920,
        maxHeight: 1920,
        imageQuality: 85,
      );
      if (xfile == null) return; // User membatalkan picker

      // Validasi path tidak kosong
      if (xfile.path.isEmpty) {
        _showSnack('Gagal mendapatkan path file foto. Coba lagi.');
        return;
      }

      final file = File(xfile.path);

      // Verifikasi file dapat diakses sebelum menyimpan ke state
      final exists = await file.exists();
      if (!exists) {
        _showSnack('File foto tidak dapat diakses. Coba pilih dari galeri.');
        return;
      }

      if (!mounted) return;
      setState(() {
        _selectedFile = file;
        _selectedType = StoryType.photo;
        _videoPreviewCtrl?.dispose();
        _videoPreviewCtrl = null;
        _videoPreviewReady = false;
      });
    } catch (e) {
      if (!mounted) return;
      _showSnack('Gagal memilih foto: $e');
    }
  }

  Future<void> _pickVideo(ImageSource source) async {
    // Jangan buka picker saat sedang upload
    if (_isUploading) return;
    try {
      final xfile = await _picker.pickVideo(
        source: source,
        maxDuration: const Duration(seconds: 30),
      );
      if (xfile == null) return; // User membatalkan picker

      // Validasi path tidak kosong
      if (xfile.path.isEmpty) {
        _showSnack('Gagal mendapatkan path file video. Coba lagi.');
        return;
      }

      final file = File(xfile.path);

      // Verifikasi file dapat diakses
      final exists = await file.exists();
      if (!exists) {
        _showSnack('File video tidak dapat diakses. Coba pilih dari galeri.');
        return;
      }

      // Inisialisasi controller preview video
      final ctrl = VideoPlayerController.file(file);
      try {
        await ctrl.initialize();
      } catch (initError) {
        ctrl.dispose();
        if (!mounted) return;
        _showSnack('Gagal memuat preview video: $initError');
        return;
      }

      if (!mounted) {
        ctrl.dispose();
        return;
      }

      // Dispose controller lama sebelum mengganti
      _videoPreviewCtrl?.dispose();

      setState(() {
        _selectedFile = file;
        _selectedType = StoryType.video;
        _videoPreviewCtrl = ctrl;
        _videoPreviewReady = true;
      });

      ctrl.play();
      ctrl.setLooping(true);
    } catch (e) {
      if (!mounted) return;
      _showSnack('Gagal memilih video: $e');
    }
  }

  // ─────────────────────────────────────────────────────────────────────────
  //  PUBLISH STORY
  // ─────────────────────────────────────────────────────────────────────────
  Future<void> _publishTextStory() async {
    final text = _textCtrl.text.trim();
    if (text.isEmpty) {
      _showSnack('Tulis sesuatu dulu!');
      return;
    }

    // Cegah double-publish
    if (_isUploading) return;

    setState(() {
      _isUploading = true;
      _uploadProgress = 0;
      _statusMsg = 'Memublikasikan...';
    });

    debugPrint('[STORY_PUBLISH] Start — type=text');

    try {
      await _service.createTextStory(
        ownerUsername: widget.ownerUsername,
        ownerRole: widget.ownerRole,
        ownerProfileUrl: widget.ownerProfileUrl,
        textContent: text,
        caption: _textCaptionCtrl.text.trim().isEmpty
            ? null
            : _textCaptionCtrl.text.trim(),
        bgColor: _selectedBg,
      );

      if (!mounted) return;
      _showSnack('Story dipublikasikan! ✓');
      Navigator.pop(context);
    } catch (e) {
      debugPrint('[STORY_PUBLISH] Failed — $e');
      if (!mounted) return;
      _showErrorDialog('Gagal mempublikasikan story teks', e.toString());
    } finally {
      if (mounted) {
        setState(() {
          _isUploading = false;
          _statusMsg = '';
        });
      }
    }
  }

  Future<void> _publishMediaStory() async {
    // Guard: file harus sudah dipilih
    if (_selectedFile == null) {
      _showSnack('Pilih foto atau video dulu!');
      return;
    }

    // Guard: pastikan tipe sesuai tab yang aktif
    final currentTab = _tabCtrl.index;
    final expectedType = currentTab == 1 ? StoryType.photo : StoryType.video;
    if (_selectedType != expectedType) {
      _showSnack(
        'Tipe media tidak sesuai. Pilih ${expectedType == StoryType.photo ? "foto" : "video"} lagi.',
      );
      return;
    }

    // Cegah double-publish
    if (_isUploading) return;

    setState(() {
      _isUploading = true;
      _uploadProgress = 0;
      _statusMsg = 'Memvalidasi media...';
    });

    debugPrint('[STORY_PUBLISH] Start — type=${_selectedType.name}');

    // Tentukan caption dari tab yang aktif
    final captionCtrl =
        _selectedType == StoryType.photo ? _photoCaptionCtrl : _videoCaptionCtrl;
    final caption =
        captionCtrl.text.trim().isEmpty ? null : captionCtrl.text.trim();

    try {
      await _service.createMediaStory(
        ownerUsername: widget.ownerUsername,
        ownerRole: widget.ownerRole,
        ownerProfileUrl: widget.ownerProfileUrl,
        mediaFile: _selectedFile!,
        type: _selectedType,
        caption: caption,
        onProgress: (p) {
          // Guard mounted sebelum setState dari callback async
          if (mounted) {
            setState(() {
              _uploadProgress = p;
              _statusMsg =
                  'Mengunggah ${(p * 100).toInt()}%...';
            });
          }
        },
      );

      if (!mounted) return;
      _showSnack('Story dipublikasikan! ✓');
      Navigator.pop(context);
    } catch (e) {
      debugPrint('[STORY_PUBLISH] Failed — $e');
      if (!mounted) return;
      _showErrorDialog(
        _selectedType == StoryType.photo
            ? 'Gagal mempublikasikan foto'
            : 'Gagal mempublikasikan video',
        e.toString(),
      );
    } finally {
      // PENTING: selalu reset loading state meskipun widget belum disposed
      if (mounted) {
        setState(() {
          _isUploading = false;
          _uploadProgress = 0;
          _statusMsg = '';
        });
      }
    }
  }

  // ─────────────────────────────────────────────────────────────────────────
  //  FEEDBACK HELPERS
  // ─────────────────────────────────────────────────────────────────────────
  void _showSnack(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(msg),
        backgroundColor: const Color(0xFF0D1117),
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  /// Tampilkan dialog error dengan pesan yang dapat dibaca user.
  /// Stack trace teknis tidak ditampilkan ke user.
  void _showErrorDialog(String title, String detail) {
    if (!mounted) return;

    // Bersihkan pesan error dari teknikal detail yang tidak perlu
    String userMsg = detail;
    // Jika pesan mengandung Exception wrapper, ambil pesan intinya
    if (userMsg.startsWith('Exception: ')) {
      userMsg = userMsg.substring('Exception: '.length);
    }

    showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: const Color(0xFF1A1F2E),
        title: Text(
          title,
          style: const TextStyle(
            color: Colors.white,
            fontSize: 16,
            fontWeight: FontWeight.w700,
          ),
        ),
        content: Text(
          userMsg,
          style: const TextStyle(color: Colors.white70, fontSize: 14),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text(
              'OK',
              style: TextStyle(color: Color(0xFF4FC3F7)),
            ),
          ),
        ],
      ),
    );
  }

  // ─────────────────────────────────────────────────────────────────────────
  //  BUILD
  // ─────────────────────────────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0D1117),
      appBar: AppBar(
        backgroundColor: const Color(0xFF0D1117),
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.close, color: Colors.white),
          // Cegah menutup screen saat upload berlangsung
          onPressed: _isUploading ? null : () => Navigator.pop(context),
        ),
        title: const Text(
          'Buat Story',
          style: TextStyle(
            color: Colors.white,
            fontSize: 16,
            fontWeight: FontWeight.w700,
          ),
        ),
        bottom: TabBar(
          controller: _tabCtrl,
          indicatorColor: const Color(0xFF4FC3F7),
          labelColor: const Color(0xFF4FC3F7),
          unselectedLabelColor: Colors.white54,
          labelStyle:
              const TextStyle(fontSize: 12, fontWeight: FontWeight.w600),
          tabs: const [
            Tab(icon: Icon(Icons.text_fields, size: 18), text: 'Teks'),
            Tab(icon: Icon(Icons.photo, size: 18), text: 'Foto'),
            Tab(icon: Icon(Icons.videocam, size: 18), text: 'Video'),
          ],
        ),
      ),
      body: Stack(
        children: [
          TabBarView(
            controller: _tabCtrl,
            children: [
              _buildTextTab(),
              _buildPhotoTab(),
              _buildVideoTab(),
            ],
          ),
          // ── Upload overlay ──────────────────────────────────────────────
          if (_isUploading)
            Container(
              color: Colors.black.withOpacity(0.75),
              child: Center(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    CircularProgressIndicator(
                      value: _uploadProgress > 0 ? _uploadProgress : null,
                      color: const Color(0xFF4FC3F7),
                    ),
                    const SizedBox(height: 16),
                    Text(
                      _statusMsg.isNotEmpty ? _statusMsg : 'Memproses...',
                      style: const TextStyle(
                          color: Colors.white, fontSize: 14),
                    ),
                    if (_uploadProgress > 0) ...[
                      const SizedBox(height: 8),
                      Text(
                        '${(_uploadProgress * 100).toInt()}%',
                        style: const TextStyle(
                            color: Colors.white54, fontSize: 12),
                      ),
                    ],
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }

  // ── TAB TEKS ───────────────────────────────────────────────────────────────
  Widget _buildTextTab() {
    final bg = _parseColor(_selectedBg);
    return Column(
      children: [
        // Preview
        Expanded(
          child: Container(
            color: bg,
            alignment: Alignment.center,
            padding: const EdgeInsets.symmetric(horizontal: 24),
            child: Text(
              _textCtrl.text.isEmpty
                  ? 'Preview teks story...'
                  : _textCtrl.text,
              style: TextStyle(
                color: _textCtrl.text.isEmpty
                    ? Colors.white30
                    : Colors.white,
                fontSize: 24,
                fontWeight: FontWeight.w700,
                height: 1.4,
              ),
              textAlign: TextAlign.center,
            ),
          ),
        ),
        // Editor panel
        Container(
          color: const Color(0xFF151B23),
          padding: const EdgeInsets.all(16),
          child: Column(
            children: [
              // Pilih warna background
              SizedBox(
                height: 36,
                child: ListView.builder(
                  scrollDirection: Axis.horizontal,
                  itemCount: _bgColors.length,
                  itemBuilder: (_, i) {
                    final selected = _bgColors[i] == _selectedBg;
                    return GestureDetector(
                      onTap: () =>
                          setState(() => _selectedBg = _bgColors[i]),
                      child: Container(
                        width: 32,
                        height: 32,
                        margin: const EdgeInsets.only(right: 8),
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: _parseColor(_bgColors[i]),
                          border: Border.all(
                            color: selected
                                ? Colors.white
                                : Colors.white24,
                            width: selected ? 2.5 : 1,
                          ),
                        ),
                      ),
                    );
                  },
                ),
              ),
              const SizedBox(height: 12),
              // Input teks
              TextField(
                controller: _textCtrl,
                onChanged: (_) => setState(() {}),
                style: const TextStyle(color: Colors.white, fontSize: 14),
                maxLines: 3,
                decoration: InputDecoration(
                  hintText: 'Tulis story kamu...',
                  hintStyle:
                      TextStyle(color: Colors.white.withOpacity(0.4)),
                  filled: true,
                  fillColor: Colors.white.withOpacity(0.06),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: BorderSide.none,
                  ),
                  contentPadding: const EdgeInsets.all(12),
                ),
              ),
              const SizedBox(height: 8),
              // Caption khusus tab teks
              TextField(
                controller: _textCaptionCtrl,
                style: const TextStyle(color: Colors.white, fontSize: 13),
                decoration: InputDecoration(
                  hintText: 'Caption (opsional)',
                  hintStyle:
                      TextStyle(color: Colors.white.withOpacity(0.3)),
                  filled: true,
                  fillColor: Colors.white.withOpacity(0.04),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: BorderSide.none,
                  ),
                  contentPadding: const EdgeInsets.symmetric(
                      horizontal: 12, vertical: 10),
                ),
              ),
              const SizedBox(height: 12),
              // Tombol publish
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: _isUploading ? null : _publishTextStory,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF00B4D8),
                    foregroundColor: const Color(0xFF0D1117),
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12)),
                    padding: const EdgeInsets.symmetric(vertical: 14),
                  ),
                  child: const Text(
                    'Publikasikan Story',
                    style:
                        TextStyle(fontWeight: FontWeight.w700, fontSize: 14),
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  // ── TAB FOTO ───────────────────────────────────────────────────────────────
  Widget _buildPhotoTab() {
    return Column(
      children: [
        // Preview area
        Expanded(
          child: _selectedFile != null && _selectedType == StoryType.photo
              ? Stack(
                  fit: StackFit.expand,
                  children: [
                    Image.file(_selectedFile!, fit: BoxFit.contain),
                    Positioned(
                      top: 8,
                      right: 8,
                      child: IconButton(
                        onPressed: _isUploading
                            ? null
                            : () => setState(() => _selectedFile = null),
                        icon: const Icon(Icons.delete_outline,
                            color: Colors.white),
                      ),
                    ),
                  ],
                )
              : Center(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(Icons.photo_library_outlined,
                          color: Colors.white24, size: 64),
                      const SizedBox(height: 12),
                      Text(
                        'Pilih foto untuk story',
                        style: TextStyle(
                            color: Colors.white.withOpacity(0.4),
                            fontSize: 14),
                      ),
                    ],
                  ),
                ),
        ),
        // Panel bawah
        Container(
          color: const Color(0xFF151B23),
          padding: const EdgeInsets.all(16),
          child: Column(
            children: [
              // Tombol pilih sumber
              Row(
                children: [
                  Expanded(
                    child: _mediaButton(
                      icon: Icons.camera_alt_outlined,
                      label: 'Kamera',
                      onTap: () => _pickImage(ImageSource.camera),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: _mediaButton(
                      icon: Icons.photo_library_outlined,
                      label: 'Galeri',
                      onTap: () => _pickImage(ImageSource.gallery),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 10),
              // Caption khusus tab foto
              TextField(
                controller: _photoCaptionCtrl,
                style:
                    const TextStyle(color: Colors.white, fontSize: 13),
                decoration: InputDecoration(
                  hintText: 'Caption (opsional)',
                  hintStyle:
                      TextStyle(color: Colors.white.withOpacity(0.3)),
                  filled: true,
                  fillColor: Colors.white.withOpacity(0.04),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: BorderSide.none,
                  ),
                  contentPadding: const EdgeInsets.symmetric(
                      horizontal: 12, vertical: 10),
                ),
              ),
              const SizedBox(height: 10),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: (_isUploading ||
                          _selectedFile == null ||
                          _selectedType != StoryType.photo)
                      ? null
                      : _publishMediaStory,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF00B4D8),
                    foregroundColor: const Color(0xFF0D1117),
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12)),
                    padding: const EdgeInsets.symmetric(vertical: 14),
                  ),
                  child: const Text(
                    'Publikasikan Foto',
                    style:
                        TextStyle(fontWeight: FontWeight.w700, fontSize: 14),
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  // ── TAB VIDEO ───────────────────────────────────────────────────────────────
  Widget _buildVideoTab() {
    return Column(
      children: [
        // Preview area
        Expanded(
          child: _videoPreviewReady && _videoPreviewCtrl != null
              ? Stack(
                  fit: StackFit.expand,
                  children: [
                    Center(
                      child: AspectRatio(
                        aspectRatio:
                            _videoPreviewCtrl!.value.aspectRatio,
                        child: VideoPlayer(_videoPreviewCtrl!),
                      ),
                    ),
                    Positioned(
                      top: 8,
                      right: 8,
                      child: IconButton(
                        onPressed: _isUploading
                            ? null
                            : () {
                                _videoPreviewCtrl?.dispose();
                                setState(() {
                                  _selectedFile = null;
                                  _videoPreviewCtrl = null;
                                  _videoPreviewReady = false;
                                });
                              },
                        icon: const Icon(Icons.delete_outline,
                            color: Colors.white),
                      ),
                    ),
                    // Play/pause overlay
                    Center(
                      child: GestureDetector(
                        onTap: () {
                          if (_videoPreviewCtrl!.value.isPlaying) {
                            _videoPreviewCtrl!.pause();
                          } else {
                            _videoPreviewCtrl!.play();
                          }
                          setState(() {});
                        },
                        child: Container(
                          color: Colors.transparent,
                          width: 60,
                          height: 60,
                          child:
                              _videoPreviewCtrl!.value.isPlaying
                                  ? const SizedBox.shrink()
                                  : const Icon(Icons.play_circle_outline,
                                      color: Colors.white70, size: 56),
                        ),
                      ),
                    ),
                  ],
                )
              : Center(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(Icons.videocam_outlined,
                          color: Colors.white24, size: 64),
                      const SizedBox(height: 12),
                      Text(
                        'Pilih video (maks. 30 detik)',
                        style: TextStyle(
                            color: Colors.white.withOpacity(0.4),
                            fontSize: 14),
                      ),
                    ],
                  ),
                ),
        ),
        // Panel bawah
        Container(
          color: const Color(0xFF151B23),
          padding: const EdgeInsets.all(16),
          child: Column(
            children: [
              Row(
                children: [
                  Expanded(
                    child: _mediaButton(
                      icon: Icons.videocam_outlined,
                      label: 'Kamera',
                      onTap: () => _pickVideo(ImageSource.camera),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: _mediaButton(
                      icon: Icons.video_library_outlined,
                      label: 'Galeri',
                      onTap: () => _pickVideo(ImageSource.gallery),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 10),
              // Caption khusus tab video
              TextField(
                controller: _videoCaptionCtrl,
                style:
                    const TextStyle(color: Colors.white, fontSize: 13),
                decoration: InputDecoration(
                  hintText: 'Caption (opsional)',
                  hintStyle:
                      TextStyle(color: Colors.white.withOpacity(0.3)),
                  filled: true,
                  fillColor: Colors.white.withOpacity(0.04),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: BorderSide.none,
                  ),
                  contentPadding: const EdgeInsets.symmetric(
                      horizontal: 12, vertical: 10),
                ),
              ),
              const SizedBox(height: 10),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: (_isUploading ||
                          _selectedFile == null ||
                          _selectedType != StoryType.video)
                      ? null
                      : _publishMediaStory,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF00B4D8),
                    foregroundColor: const Color(0xFF0D1117),
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12)),
                    padding: const EdgeInsets.symmetric(vertical: 14),
                  ),
                  child: const Text(
                    'Publikasikan Video',
                    style:
                        TextStyle(fontWeight: FontWeight.w700, fontSize: 14),
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  // ── Tombol media sumber ────────────────────────────────────────────────────
  Widget _mediaButton({
    required IconData icon,
    required String label,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: _isUploading ? null : onTap,
      child: Container(
        padding:
            const EdgeInsets.symmetric(vertical: 12),
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(_isUploading ? 0.03 : 0.06),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: Colors.white12),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon,
                color: _isUploading
                    ? Colors.white24
                    : const Color(0xFF4FC3F7),
                size: 18),
            const SizedBox(width: 6),
            Text(
              label,
              style: TextStyle(
                  color: _isUploading ? Colors.white24 : Colors.white,
                  fontSize: 13),
            ),
          ],
        ),
      ),
    );
  }

  Color _parseColor(String hex) {
    try {
      final h = hex.replaceAll('#', '');
      return Color(int.parse('FF$h', radix: 16));
    } catch (_) {
      return const Color(0xFF0D1117);
    }
  }
}
