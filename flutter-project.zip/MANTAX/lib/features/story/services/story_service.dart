// lib/features/story/services/story_service.dart
//
// Service Story — menggunakan Firebase Realtime Database (existing)
// Firebase Database URL: https://dentmvn1-default-rtdb.asia-southeast1.firebasedatabase.app/
// Firebase Storage: untuk upload media foto/video
//
// Struktur node Firebase:
//   stories/
//     {storyId}/
//       id, ownerUsername, ownerRole, ownerProfileUrl, type,
//       mediaUrl, textContent, caption, bgColor,
//       createdAt, expiresAt, isProcessing
//       viewers/
//         {username}: timestampMs

import 'dart:async';
import 'dart:io';
import 'dart:math';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/foundation.dart';
import '../models/story_model.dart';

class StoryService {
  StoryService._();
  static final StoryService instance = StoryService._();

  // ── Firebase refs ────────────────────────────────────────────────────────
  DatabaseReference get _db => FirebaseDatabase.instanceFor(
        app: Firebase.app(),
        databaseURL:
            'https://dentmvn1-default-rtdb.asia-southeast1.firebasedatabase.app/',
      ).ref('stories');

  FirebaseStorage get _storage => FirebaseStorage.instance;

  static const Duration _storyDuration = Duration(hours: 24);

  // ── Buat ID unik ──────────────────────────────────────────────────────────
  String _generateId() {
    final ts = DateTime.now().millisecondsSinceEpoch;
    final rand = Random().nextInt(999999).toString().padLeft(6, '0');
    return 'story_${ts}_$rand';
  }

  // ─────────────────────────────────────────────────────────────────────────
  //  VALIDASI FILE SEBELUM UPLOAD
  // ─────────────────────────────────────────────────────────────────────────
  /// Melempar [Exception] jika file tidak valid atau tidak bisa dibaca.
  Future<void> _validateFile(File file, StoryType type) async {
    // 1. Path tidak boleh kosong
    if (file.path.isEmpty) {
      throw Exception('Path file kosong. Pilih media lagi.');
    }

    // 2. File harus ada di disk
    final exists = await file.exists();
    if (!exists) {
      throw Exception(
        'File media tidak ditemukan di path: ${file.path}\n'
        'File mungkin sudah dihapus sistem. Pilih media lagi.',
      );
    }

    // 3. File tidak boleh kosong (0 byte)
    final length = await file.length();
    if (length == 0) {
      throw Exception('File media berukuran 0 byte. Pilih media lagi.');
    }

    // 4. Batas ukuran: foto 20 MB, video 100 MB
    final maxBytes = type == StoryType.video
        ? 100 * 1024 * 1024   // 100 MB
        : 20 * 1024 * 1024;   //  20 MB
    if (length > maxBytes) {
      final limitMb = maxBytes ~/ (1024 * 1024);
      final sizeMb = (length / (1024 * 1024)).toStringAsFixed(1);
      throw Exception(
        'Ukuran file ($sizeMb MB) melebihi batas ${limitMb} MB untuk '
        '${type == StoryType.video ? "video" : "foto"}.',
      );
    }

    debugPrint(
      '[STORY_PUBLISH] File validation OK — '
      'path=${file.path}, size=${length}B, type=${type.name}',
    );
  }

  // ─────────────────────────────────────────────────────────────────────────
  //  DAPATKAN EKSTENSI FILE YANG VALID
  // ─────────────────────────────────────────────────────────────────────────
  /// Mengekstrak ekstensi dari path file.
  /// Fallback ke ekstensi default jika tidak ditemukan.
  String _safeExtension(File file, StoryType type) {
    try {
      final path = file.path;
      // Ambil bagian terakhir setelah '/' atau '\'
      final filename = path.split(RegExp(r'[/\\]')).last;
      // Cari titik terakhir di nama file
      final dotIndex = filename.lastIndexOf('.');
      if (dotIndex >= 0 && dotIndex < filename.length - 1) {
        final ext = filename.substring(dotIndex + 1).toLowerCase();
        // Pastikan ekstensi hanya berisi karakter alfanumerik
        if (RegExp(r'^[a-z0-9]+$').hasMatch(ext) && ext.length <= 5) {
          return ext;
        }
      }
    } catch (_) {}
    // Fallback berdasarkan tipe
    return type == StoryType.video ? 'mp4' : 'jpg';
  }

  // ─────────────────────────────────────────────────────────────────────────
  //  DAPATKAN CONTENT TYPE YANG BENAR
  // ─────────────────────────────────────────────────────────────────────────
  String _contentType(String ext, StoryType type) {
    if (type == StoryType.video) {
      const videoTypes = {
        'mp4': 'video/mp4',
        'mov': 'video/quicktime',
        'avi': 'video/x-msvideo',
        'mkv': 'video/x-matroska',
        'webm': 'video/webm',
        '3gp': 'video/3gpp',
      };
      return videoTypes[ext] ?? 'video/mp4';
    } else {
      const imageTypes = {
        'jpg': 'image/jpeg',
        'jpeg': 'image/jpeg',
        'png': 'image/png',
        'webp': 'image/webp',
        'gif': 'image/gif',
        'heic': 'image/heic',
        'heif': 'image/heif',
      };
      return imageTypes[ext] ?? 'image/jpeg';
    }
  }

  // ─────────────────────────────────────────────────────────────────────────
  //  UPLOAD MEDIA KE FIREBASE STORAGE
  // ─────────────────────────────────────────────────────────────────────────
  Future<String> uploadMedia({
    required File file,
    required String storyId,
    required StoryType type,
    void Function(double)? onProgress,
  }) async {
    debugPrint('[STORY_PUBLISH] Upload started — storyId=$storyId, type=${type.name}');

    final ext = _safeExtension(file, type);
    final mimeType = _contentType(ext, type);
    final folder = type == StoryType.video ? 'story_videos' : 'story_photos';
    final storagePath = '$folder/$storyId.$ext';

    debugPrint('[STORY_PUBLISH] Storage path: $storagePath, MIME: $mimeType');

    final ref = _storage.ref(storagePath);

    final task = ref.putFile(
      file,
      SettableMetadata(contentType: mimeType),
    );

    // ── Progress listener ──────────────────────────────────────────────────
    // Gunakan StreamSubscription agar bisa di-cancel saat task selesai/error.
    // PENTING: jangan await listener ini — hanya untuk update progress UI.
    StreamSubscription<TaskSnapshot>? progressSub;
    if (onProgress != null) {
      progressSub = task.snapshotEvents.listen(
        (snap) {
          if (snap.totalBytes > 0) {
            final progress = snap.bytesTransferred / snap.totalBytes;
            onProgress(progress);
          }
        },
        onError: (e) {
          // Error dari stream sudah akan dilempar oleh `await task` di bawah.
          // Tidak perlu rethrow di sini — cukup log saja.
          debugPrint('[STORY_PUBLISH] Progress stream error (handled by await task): $e');
        },
        cancelOnError: false,
      );
    }

    try {
      // ── Tunggu upload selesai ─────────────────────────────────────────────
      // `await task` akan melempar FirebaseException jika upload gagal.
      final snapshot = await task;

      debugPrint(
        '[STORY_PUBLISH] Upload completed — '
        'bytes=${snapshot.bytesTransferred}, state=${snapshot.state}',
      );

      if (snapshot.state != TaskState.success) {
        throw Exception(
          'Upload selesai tetapi state tidak sukses: ${snapshot.state}',
        );
      }

      // ── Ambil download URL ─────────────────────────────────────────────
      debugPrint('[STORY_PUBLISH] Fetching download URL...');
      final url = await ref.getDownloadURL();

      if (url.isEmpty) {
        throw Exception('Download URL kosong setelah upload berhasil.');
      }

      debugPrint('[STORY_PUBLISH] Media URL resolved: [URL tersembunyi untuk keamanan]');
      return url;
    } on FirebaseException catch (e, stack) {
      debugPrint('[STORY_PUBLISH] FirebaseException saat upload: code=${e.code}, msg=${e.message}');
      debugPrintStack(label: '[STORY_PUBLISH] Stack', stackTrace: stack);
      // Terjemahkan kode error Firebase yang umum agar lebih mudah dimengerti
      String userMsg;
      switch (e.code) {
        case 'storage/unauthorized':
          userMsg = 'Akses ditolak oleh Firebase Storage. Periksa Security Rules.';
          break;
        case 'storage/canceled':
          userMsg = 'Upload dibatalkan.';
          break;
        case 'storage/object-not-found':
          userMsg = 'File tidak ditemukan di storage.';
          break;
        case 'storage/quota-exceeded':
          userMsg = 'Kuota Firebase Storage habis.';
          break;
        case 'storage/retry-limit-exceeded':
          userMsg = 'Waktu upload habis. Periksa koneksi internet.';
          break;
        case 'storage/invalid-checksum':
          userMsg = 'File rusak saat transfer. Coba lagi.';
          break;
        default:
          userMsg = 'Upload gagal: ${e.message ?? e.code}';
      }
      throw Exception(userMsg);
    } catch (e, stack) {
      debugPrint('[STORY_PUBLISH] Error saat upload: $e');
      debugPrintStack(label: '[STORY_PUBLISH] Stack', stackTrace: stack);
      rethrow;
    } finally {
      // Cancel progress listener agar tidak ada memory leak
      await progressSub?.cancel();
    }
  }

  // ─────────────────────────────────────────────────────────────────────────
  //  BUAT STORY TEKS
  // ─────────────────────────────────────────────────────────────────────────
  Future<String> createTextStory({
    required String ownerUsername,
    required String ownerRole,
    String? ownerProfileUrl,
    required String textContent,
    String? caption,
    String bgColor = '#0D1117',
  }) async {
    debugPrint('[STORY_PUBLISH] Start — type=text, owner=$ownerUsername');

    final id = _generateId();
    final now = DateTime.now().millisecondsSinceEpoch;
    final story = StoryModel(
      id: id,
      ownerUsername: ownerUsername,
      ownerRole: ownerRole,
      ownerProfileUrl: ownerProfileUrl,
      type: StoryType.text,
      textContent: textContent,
      caption: caption,
      bgColor: bgColor,
      createdAt: now,
      expiresAt: now + _storyDuration.inMilliseconds,
    );

    debugPrint('[STORY_PUBLISH] Metadata save started — id=$id');
    await _db.child(id).set(story.toMap());
    debugPrint('[STORY_PUBLISH] Metadata save completed');
    debugPrint('[STORY_PUBLISH] Text story created: $id');
    return id;
  }

  // ─────────────────────────────────────────────────────────────────────────
  //  BUAT STORY FOTO / VIDEO
  // ─────────────────────────────────────────────────────────────────────────
  Future<String> createMediaStory({
    required String ownerUsername,
    required String ownerRole,
    String? ownerProfileUrl,
    required File mediaFile,
    required StoryType type,
    String? caption,
    void Function(double)? onProgress,
  }) async {
    debugPrint('[STORY_PUBLISH] Start — type=${type.name}, owner=$ownerUsername');

    // ── Langkah 1: Validasi file ──────────────────────────────────────────
    debugPrint('[STORY_PUBLISH] Media validation started');
    await _validateFile(mediaFile, type);
    debugPrint('[STORY_PUBLISH] Media validation succeeded');

    final id = _generateId();
    final now = DateTime.now().millisecondsSinceEpoch;

    // ── Langkah 2: Simpan placeholder agar tray menampilkan loading ───────
    final placeholderStory = StoryModel(
      id: id,
      ownerUsername: ownerUsername,
      ownerRole: ownerRole,
      ownerProfileUrl: ownerProfileUrl,
      type: type,
      caption: caption,
      createdAt: now,
      expiresAt: now + _storyDuration.inMilliseconds,
      isProcessing: true,
    );

    debugPrint('[STORY_PUBLISH] Saving placeholder to database...');
    await _db.child(id).set(placeholderStory.toMap());
    debugPrint('[STORY_PUBLISH] Placeholder saved, storyId=$id');

    String? mediaUrl;
    try {
      // ── Langkah 3: Upload media ─────────────────────────────────────────
      mediaUrl = await uploadMedia(
        file: mediaFile,
        storyId: id,
        type: type,
        onProgress: onProgress,
      );

      // ── Langkah 4: Update metadata dengan URL dan hapus flag processing ─
      debugPrint('[STORY_PUBLISH] Metadata save started — updating mediaUrl & isProcessing');
      await _db.child(id).update({
        'mediaUrl': mediaUrl,
        'isProcessing': false,
      });
      debugPrint('[STORY_PUBLISH] Metadata save completed');
      debugPrint('[STORY_PUBLISH] State refresh completed — storyId=$id');

      debugPrint('[STORY_PUBLISH] Media story created successfully: $id');
      return id;
    } catch (e, stack) {
      debugPrint('[STORY_PUBLISH] Failed — storyId=$id, error=$e');
      debugPrintStack(label: '[STORY_PUBLISH] Stack', stackTrace: stack);

      // Hapus placeholder agar tidak ada orphan data di database
      try {
        await _db.child(id).remove();
        debugPrint('[STORY_PUBLISH] Placeholder removed after failure');
      } catch (cleanupError) {
        debugPrint('[STORY_PUBLISH] Cleanup failed (non-critical): $cleanupError');
      }

      // Rethrow agar editor screen bisa menampilkan pesan error ke user
      rethrow;
    }
  }

  // ─────────────────────────────────────────────────────────────────────────
  //  STREAM SEMUA STORY AKTIF (realtime)
  // ─────────────────────────────────────────────────────────────────────────
  Stream<List<StoryModel>> streamActiveStories() {
    return _db.onValue.map((event) {
      if (!event.snapshot.exists) return [];
      final raw = event.snapshot.value;
      if (raw is! Map) return [];

      final nowMs = DateTime.now().millisecondsSinceEpoch;
      final stories = <StoryModel>[];

      raw.forEach((key, value) {
        if (value is Map) {
          try {
            final story = StoryModel.fromMap(key.toString(), value);
            // Filter: aktif (belum expired) dan tidak sedang processing
            if (story.expiresAt > nowMs && !story.isProcessing) {
              stories.add(story);
            }
          } catch (e) {
            debugPrint('[StoryService] Parse error key=$key: $e');
          }
        }
      });

      // Urutkan: terbaru lebih dulu
      stories.sort((a, b) => b.createdAt.compareTo(a.createdAt));
      return stories;
    });
  }

  // ─────────────────────────────────────────────────────────────────────────
  //  GRUP STORY BERDASARKAN PEMILIK
  // ─────────────────────────────────────────────────────────────────────────
  List<StoryOwnerGroup> groupByOwner(
    List<StoryModel> stories,
    String currentUser,
  ) {
    final Map<String, List<StoryModel>> map = {};
    for (final s in stories) {
      map.putIfAbsent(s.ownerUsername, () => []).add(s);
    }

    final groups = map.entries.map((e) {
      final ownerStories = e.value;
      return StoryOwnerGroup(
        ownerUsername: e.key,
        ownerRole: ownerStories.first.ownerRole,
        ownerProfileUrl: ownerStories.first.ownerProfileUrl,
        stories: ownerStories,
      );
    }).toList();

    // Pemilik sendiri selalu di depan
    groups.sort((a, b) {
      if (a.ownerUsername == currentUser) return -1;
      if (b.ownerUsername == currentUser) return 1;
      // Yang ada unviewed story lebih depan
      final aUnviewed = a.hasUnviewed ? 0 : 1;
      final bUnviewed = b.hasUnviewed ? 0 : 1;
      if (aUnviewed != bUnviewed) return aUnviewed - bUnviewed;
      return b.latestStory.createdAt.compareTo(a.latestStory.createdAt);
    });

    return groups;
  }

  // ─────────────────────────────────────────────────────────────────────────
  //  CATAT VIEW
  // ─────────────────────────────────────────────────────────────────────────
  Future<void> recordView({
    required String storyId,
    required String viewerUsername,
    required String ownerUsername,
  }) async {
    // Jangan catat pemilik sebagai viewer
    if (viewerUsername == ownerUsername) return;

    final viewerRef = _db.child('$storyId/viewers/$viewerUsername');
    // Idempotent: hanya catat sekali per viewer per story
    final snap = await viewerRef.get();
    if (!snap.exists) {
      await viewerRef.set(DateTime.now().millisecondsSinceEpoch);
    }
  }

  // ─────────────────────────────────────────────────────────────────────────
  //  STREAM VIEWERS STORY TERTENTU (untuk panel viewers milik pemilik)
  // ─────────────────────────────────────────────────────────────────────────
  Stream<Map<String, int>> streamViewers(String storyId) {
    return _db.child('$storyId/viewers').onValue.map((event) {
      if (!event.snapshot.exists) return {};
      final raw = event.snapshot.value;
      if (raw is! Map) return {};
      final result = <String, int>{};
      raw.forEach((k, v) {
        result[k.toString()] = (v as num?)?.toInt() ?? 0;
      });
      return result;
    });
  }

  // ─────────────────────────────────────────────────────────────────────────
  //  HAPUS STORY (oleh pemilik)
  // ─────────────────────────────────────────────────────────────────────────
  Future<void> deleteStory(StoryModel story) async {
    // Hapus media dari storage jika ada
    if (story.mediaUrl != null && story.mediaUrl!.isNotEmpty) {
      try {
        final ref = _storage.refFromURL(story.mediaUrl!);
        await ref.delete();
      } catch (e) {
        debugPrint('[StoryService] Storage delete failed (non-critical): $e');
      }
    }
    await _db.child(story.id).remove();
    debugPrint('[StoryService] Story deleted: ${story.id}');
  }

  // ─────────────────────────────────────────────────────────────────────────
  //  CLEANUP STORY EXPIRED (jalankan saat app dibuka)
  //  Hanya menghapus metadata — media di Storage tidak dihapus di sini
  //  karena penghapusan media memerlukan verifikasi tidak ada referensi lain.
  //  Untuk produksi, gunakan Firebase Cloud Functions scheduled cleanup.
  // ─────────────────────────────────────────────────────────────────────────
  Future<void> cleanupExpiredMetadata() async {
    try {
      final snap = await _db.get();
      if (!snap.exists || snap.value is! Map) return;
      final nowMs = DateTime.now().millisecondsSinceEpoch;
      final raw = snap.value as Map;
      for (final entry in raw.entries) {
        final val = entry.value;
        if (val is Map) {
          final expiresAt = (val['expiresAt'] as num?)?.toInt() ?? 0;
          if (expiresAt > 0 && expiresAt < nowMs) {
            await _db.child(entry.key.toString()).remove();
            debugPrint('[StoryService] Expired story removed: ${entry.key}');
          }
        }
      }
    } catch (e) {
      debugPrint('[StoryService] Cleanup error (non-critical): $e');
    }
  }
}
