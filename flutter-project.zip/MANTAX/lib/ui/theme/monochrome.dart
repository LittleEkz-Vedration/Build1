import 'package:otax/ui/theme/types.dart';
import 'package:flutter/material.dart';

class Monochrome implements ThemeItem {
  @override
  int get id => 02;

  @override
  bool get dev => false;

  @override
  AnimeStreamTheme get lightVariant => AnimeStreamTheme(
    accentColor: Colors.black,
    backgroundColor: Colors.white,
    backgroundSubColor: const Color.fromARGB(255, 172, 172, 172),
    textMainColor: Colors.black,
    textSubColor: Colors.black,
    modalSheetBackgroundColor: Colors.white,
    onAccent: Colors.white,
  );

  @override
  String get name => "Monochrome";

  @override
  AnimeStreamTheme get theme => AnimeStreamTheme(
    accentColor: Colors.white,
    backgroundColor: Colors.black,
    backgroundSubColor: Color(0x1AFFFFFF),           // liquid glass white panel
    textMainColor: Colors.white,
    textSubColor: Color.fromARGB(255, 180, 180, 180),
    modalSheetBackgroundColor: Color(0x99000000),    // liquid glass dark modal
    onAccent: Colors.black,
  );
}
