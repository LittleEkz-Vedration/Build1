import 'package:firebase_core/firebase_core.dart' show FirebaseOptions;
import 'package:flutter/foundation.dart'
    show defaultTargetPlatform, kIsWeb, TargetPlatform;

class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    if (kIsWeb) {
      return web;
    }
    switch (defaultTargetPlatform) {
      case TargetPlatform.android:
        return android;
      case TargetPlatform.iOS:
      case TargetPlatform.macOS:
      case TargetPlatform.windows:
      case TargetPlatform.linux:
        throw UnsupportedError(
          'DefaultFirebaseOptions are not supported for this platform.',
        );
      default:
        throw UnsupportedError(
          'DefaultFirebaseOptions are not supported for this platform.',
        );
    }
  }

  // ✅ Firebase API key sudah diisi dengan key asli dari google-services.json
  // Package: com.omnix.genz | Project: dentmvn1

  static const FirebaseOptions android = FirebaseOptions(
    apiKey: 'AIzaSyDmVWCagleeXvRfS9xhWNPpGPb_rNO_J_Q',
    appId: '1:437524165373:android:6968ff09a1eeebc4d40494',
    messagingSenderId: '437524165373',
    projectId: 'dentmvn1',
    storageBucket: 'dentmvn1.firebasestorage.app',
    databaseURL:
        'https://dentmvn1-default-rtdb.asia-southeast1.firebasedatabase.app',
  );

  static const FirebaseOptions web = FirebaseOptions(
    apiKey: 'AIzaSyDmVWCagleeXvRfS9xhWNPpGPb_rNO_J_Q',
    appId: '1:437524165373:android:6968ff09a1eeebc4d40494',
    messagingSenderId: '437524165373',
    projectId: 'dentmvn1',
    storageBucket: 'dentmvn1.firebasestorage.app',
    databaseURL:
        'https://dentmvn1-default-rtdb.asia-southeast1.firebasedatabase.app',
  );
}
