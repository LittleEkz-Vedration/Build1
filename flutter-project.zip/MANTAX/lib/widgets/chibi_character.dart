// lib/widgets/chibi_character.dart
//
// ══════════════════════════════════════════════════════════════════════════════
//  OTAX CHIBI ANIMATION ENGINE
//  SDK    : Dart >=3.8.1, Flutter >=3.7.0
//  Aset   : assets/images/chibi.png   (PNG transparan, ~60–120 KB)
//
//  Cara kerja (satu PNG):
//    • Gerakan POSISI (walk kiri‑kanan)  → AnimationController _walkCtrl
//    • FLIP horizontal saat balik arah   → Transform.scale(scaleX: -1/+1)
//    • Lompat (jump)                     → AnimationController _jumpCtrl
//    • Bounce idle                       → AnimationController _idleCtrl
//    • Reaksi tap (bounce besar)         → AnimationController _tapCtrl
//    • Lifecycle – berhenti saat inactive → WidgetsBindingObserver
//
//  BATASAN FISIK PNG TUNGGAL:
//    Animasi anggota tubuh realistis (kaki melangkah, lengan bergerak)
//    memerlukan sprite‑sheet atau beberapa frame PNG terpisah. Dengan satu
//    PNG hanya bisa: posisi, skala, rotasi ringan, flip, bounce.
// ══════════════════════════════════════════════════════════════════════════════

import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';

// ─────────────────────────────────────────────────────────────────────────────
//  ENUM STATE
// ─────────────────────────────────────────────────────────────────────────────
enum ChibiState {
  idle,    // diam, bounce kecil
  walking, // jalan kiri / kanan
  jumping, // lompat
  tapped,  // reaksi saat disentuh
}

// ─────────────────────────────────────────────────────────────────────────────
//  WIDGET PUBLIK
// ─────────────────────────────────────────────────────────────────────────────
class ChibiCharacter extends StatefulWidget {
  /// Path aset PNG transparan, default `assets/images/chibi.png`
  final String assetPath;

  /// Tinggi area gerakan chibi di dalam dashboard (default 120 px)
  final double areaHeight;

  /// Ukuran gambar chibi (default 72 px)
  final double chibiSize;

  /// Apakah chibi aktif? Bisa dikontrol dari parent (mis. saat halaman inactive)
  final bool active;

  const ChibiCharacter({
    super.key,
    this.assetPath = 'assets/images/chibi.png',
    this.areaHeight = 120,
    this.chibiSize = 72,
    this.active = true,
  });

  @override
  State<ChibiCharacter> createState() => _ChibiCharacterState();
}

// ─────────────────────────────────────────────────────────────────────────────
//  STATE
// ─────────────────────────────────────────────────────────────────────────────
class _ChibiCharacterState extends State<ChibiCharacter>
    with TickerProviderStateMixin, WidgetsBindingObserver {
  // ── Controllers ─────────────────────────────────────────────────────────
  late AnimationController _walkCtrl;   // posisi X (0→1)
  late AnimationController _jumpCtrl;   // lompat (0→1→0)
  late AnimationController _idleCtrl;   // bounce idle (repeat)
  late AnimationController _tapCtrl;    // reaksi tap (single)

  // ── Animations ──────────────────────────────────────────────────────────
  late Animation<double> _walkAnim;     // 0.0 → 1.0  (fraksi lebar area)
  late Animation<double> _jumpAnim;     // offset Y vertikal
  late Animation<double> _idleAnim;     // skala kecil naik‑turun
  late Animation<double> _tapScaleAnim; // scale bounce saat tap

  // ── State lokal ─────────────────────────────────────────────────────────
  ChibiState _state = ChibiState.idle;
  bool _facingRight = true;   // arah hadap
  double _posX = 0.0;         // posisi X saat ini (fraksi 0–1)
  final math.Random _rng = math.Random();
  bool _appActive = true;     // status lifecycle

  // ── Scheduled next action ───────────────────────────────────────────────
  // Pakai TickerFuture / Future.delayed singkat agar tidak ada Timer terpisah
  bool _schedulePending = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);

    _buildControllers();
    _idleCtrl.repeat(reverse: true);

    // Mulai dengan idle sebentar lalu jalan
    _scheduleNextAction(const Duration(milliseconds: 800));
  }

  // ─────────────────────────────────────────────────────────────────────────
  //  CONTROLLER SETUP
  // ─────────────────────────────────────────────────────────────────────────
  void _buildControllers() {
    // 1) Walk controller – durasi akan disesuaikan saat memulai gerakan
    _walkCtrl = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 4),
    );
    _walkAnim = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _walkCtrl, curve: Curves.linear),
    );

    // 2) Jump controller
    _jumpCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 600),
    );
    _jumpAnim = TweenSequence<double>([
      TweenSequenceItem(
        tween: Tween<double>(begin: 0, end: -48)
            .chain(CurveTween(curve: Curves.easeOut)),
        weight: 45,
      ),
      TweenSequenceItem(
        tween: Tween<double>(begin: -48, end: 0)
            .chain(CurveTween(curve: Curves.easeIn)),
        weight: 55,
      ),
    ]).animate(_jumpCtrl);

    // 3) Idle bounce
    _idleCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
    );
    _idleAnim = Tween<double>(begin: 1.0, end: 1.06).animate(
      CurvedAnimation(parent: _idleCtrl, curve: Curves.easeInOut),
    );

    // 4) Tap reaction
    _tapCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 400),
    );
    _tapScaleAnim = TweenSequence<double>([
      TweenSequenceItem(
        tween: Tween<double>(begin: 1.0, end: 1.35)
            .chain(CurveTween(curve: Curves.easeOut)),
        weight: 40,
      ),
      TweenSequenceItem(
        tween: Tween<double>(begin: 1.35, end: 0.9)
            .chain(CurveTween(curve: Curves.easeIn)),
        weight: 30,
      ),
      TweenSequenceItem(
        tween: Tween<double>(begin: 0.9, end: 1.0)
            .chain(CurveTween(curve: Curves.elasticOut)),
        weight: 30,
      ),
    ]).animate(_tapCtrl);
  }

  // ─────────────────────────────────────────────────────────────────────────
  //  LIFECYCLE OBSERVER
  // ─────────────────────────────────────────────────────────────────────────
  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    final wasActive = _appActive;
    _appActive = state == AppLifecycleState.resumed;

    if (!_appActive && wasActive) {
      // Pause semua controller saat app masuk background / inactive
      _walkCtrl.stop();
      _jumpCtrl.stop();
      _idleCtrl.stop();
      _tapCtrl.stop();
    } else if (_appActive && !wasActive) {
      // Resume
      _idleCtrl.repeat(reverse: true);
      _scheduleNextAction(const Duration(milliseconds: 500));
    }
  }

  // ─────────────────────────────────────────────────────────────────────────
  //  SCHEDULER – menghindari Timer.periodic dengan AnimationController
  // ─────────────────────────────────────────────────────────────────────────
  void _scheduleNextAction(Duration delay) {
    if (_schedulePending || !mounted) return;
    _schedulePending = true;

    Future.delayed(delay, () {
      _schedulePending = false;
      if (!mounted || !_appActive || !widget.active) return;
      _pickNextAction();
    });
  }

  void _pickNextAction() {
    if (!mounted) return;

    final roll = _rng.nextInt(10); // 0–9

    if (roll < 5) {
      // 50% → jalan
      _startWalking();
    } else if (roll < 7) {
      // 20% → lompat lalu idle
      _startJump();
    } else {
      // 30% → idle sebentar
      _setState(ChibiState.idle);
      _scheduleNextAction(Duration(milliseconds: 800 + _rng.nextInt(1200)));
    }
  }

  // ─────────────────────────────────────────────────────────────────────────
  //  JALAN
  // ─────────────────────────────────────────────────────────────────────────
  void _startWalking() {
    if (!mounted) return;

    // Tentukan tujuan (posisi X tujuan dalam fraksi 0–1)
    final double target = _rng.nextDouble() * 0.85; // sisakan margin
    final double distanceFraction = (target - _posX).abs();
    if (distanceFraction < 0.05) {
      // Terlalu dekat, skip
      _scheduleNextAction(const Duration(milliseconds: 400));
      return;
    }

    // Arah hadap
    final bool goRight = target > _posX;
    if (_facingRight != goRight) {
      if (mounted) setState(() => _facingRight = goRight);
    }

    // Durasi proporsional jarak (1 unit = 4 detik)
    final int durationMs = (distanceFraction * 4000).clamp(800, 4000).toInt();
    _walkCtrl.duration = Duration(milliseconds: durationMs);

    // Tween dari posisi saat ini ke target
    _walkAnim = Tween<double>(begin: _posX, end: target).animate(
      CurvedAnimation(parent: _walkCtrl, curve: Curves.linear),
    );

    _setState(ChibiState.walking);
    _walkCtrl.reset();
    _walkCtrl.forward().then((_) {
      if (!mounted) return;
      _posX = target;
      _setState(ChibiState.idle);
      _scheduleNextAction(Duration(milliseconds: 600 + _rng.nextInt(800)));
    });
  }

  // ─────────────────────────────────────────────────────────────────────────
  //  LOMPAT
  // ─────────────────────────────────────────────────────────────────────────
  void _startJump() {
    if (!mounted) return;
    _setState(ChibiState.jumping);
    _jumpCtrl.reset();
    _jumpCtrl.forward().then((_) {
      if (!mounted) return;
      _setState(ChibiState.idle);
      _scheduleNextAction(Duration(milliseconds: 500 + _rng.nextInt(1000)));
    });
  }

  // ─────────────────────────────────────────────────────────────────────────
  //  TAP REACTION
  // ─────────────────────────────────────────────────────────────────────────
  void _onTap() {
    if (!mounted) return;
    // Hentikan gerakan berjalan jika sedang berjalan
    if (_state == ChibiState.walking) {
      _walkCtrl.stop();
      // Simpan posisi saat ini
      _posX = _walkAnim.value;
    }
    _setState(ChibiState.tapped);
    _tapCtrl.reset();
    _tapCtrl.forward().then((_) {
      if (!mounted) return;
      // Setelah tap, lompat kecil
      _startJump();
    });
  }

  // ─────────────────────────────────────────────────────────────────────────
  //  HELPER setState
  // ─────────────────────────────────────────────────────────────────────────
  void _setState(ChibiState newState) {
    if (!mounted) return;
    setState(() => _state = newState);
  }

  // ─────────────────────────────────────────────────────────────────────────
  //  DISPOSE
  // ─────────────────────────────────────────────────────────────────────────
  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _walkCtrl.dispose();
    _jumpCtrl.dispose();
    _idleCtrl.dispose();
    _tapCtrl.dispose();
    super.dispose();
  }

  // ─────────────────────────────────────────────────────────────────────────
  //  BUILD
  // ─────────────────────────────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    // Widget dihentikan jika prop active = false
    if (!widget.active) return const SizedBox.shrink();

    return RepaintBoundary(
      child: LayoutBuilder(
        builder: (context, constraints) {
          final double areaW = constraints.maxWidth;
          final double areaH = widget.areaHeight;
          final double size = widget.chibiSize;
          // Batas kiri‑kanan agar tidak keluar area
          final double maxX = (areaW - size).clamp(0, double.infinity);

          return SizedBox(
            width: areaW,
            height: areaH,
            child: GestureDetector(
              behavior: HitTestBehavior.translucent,
              onTapDown: (_) => _onTap(),
              child: AnimatedBuilder(
                animation: Listenable.merge([
                  _walkCtrl,
                  _jumpCtrl,
                  _idleCtrl,
                  _tapCtrl,
                ]),
                builder: (context, _) {
                  // Hitung posisi X berdasarkan state
                  final double xFraction = _state == ChibiState.walking
                      ? _walkAnim.value
                      : _posX;
                  final double left = (xFraction * maxX).clamp(0, maxX);

                  // Offset Y dari lompat
                  final double jumpOffset =
                      _state == ChibiState.jumping ? _jumpAnim.value : 0;

                  // Skala: idle bounce × tap scale
                  final double idleScale =
                      _state != ChibiState.walking ? _idleAnim.value : 1.0;
                  final double tapScale =
                      _state == ChibiState.tapped ? _tapScaleAnim.value : 1.0;
                  final double finalScale = idleScale * tapScale;

                  // Kemiringan ringan saat berjalan (simulasi langkah)
                  double tiltAngle = 0;
                  if (_state == ChibiState.walking) {
                    final double t = _walkCtrl.value;
                    // Osilasi ±3° menggunakan sin – sekali setengah cycle/detik
                    tiltAngle = math.sin(t * math.pi * 14) * 0.052; // rad ≈ 3°
                  }

                  return Stack(
                    clipBehavior: Clip.none,
                    children: [
                      Positioned(
                        left: left,
                        bottom: 0,
                        child: Transform.translate(
                          offset: Offset(0, jumpOffset),
                          child: Transform.rotate(
                            angle: tiltAngle,
                            child: Transform.scale(
                              // Flip horizontal sesuai arah
                              scaleX: _facingRight ? finalScale : -finalScale,
                              scaleY: finalScale,
                              child: _buildChibiImage(size),
                            ),
                          ),
                        ),
                      ),
                    ],
                  );
                },
              ),
            ),
          );
        },
      ),
    );
  }

  // ─────────────────────────────────────────────────────────────────────────
  //  GAMBAR CHIBI
  // ─────────────────────────────────────────────────────────────────────────
  Widget _buildChibiImage(double size) {
    return SizedBox(
      width: size,
      height: size,
      child: Image.asset(
        widget.assetPath,
        width: size,
        height: size,
        fit: BoxFit.contain,
        // filterQuality smooth tapi tidak terlalu mahal
        filterQuality: FilterQuality.medium,
        // Fallback: icon lucu jika PNG belum ada
        errorBuilder: (context, error, stack) => _buildFallback(size),
      ),
    );
  }

  Widget _buildFallback(double size) {
    // Placeholder sementara sebelum chibi.png ditambahkan ke assets
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.15),
        borderRadius: BorderRadius.circular(size / 2),
        border: Border.all(
          color: Colors.white.withOpacity(0.3),
          width: 1.5,
        ),
      ),
      child: Center(
        child: Text(
          '(◕‿◕)',
          style: TextStyle(
            fontSize: size * 0.28,
            color: Colors.white.withOpacity(0.85),
          ),
        ),
      ),
    );
  }
}
