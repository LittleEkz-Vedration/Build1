import 'dart:io';
import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

import 'maintenance_service.dart';
import 'main.dart'; // baseUrl

/// Halaman admin maintenance – hanya boleh dibuka oleh KINGZ.
class MaintenanceAdminPage extends StatefulWidget {
  final String sessionKey;
  final String username;
  final String role;

  const MaintenanceAdminPage({
    super.key,
    required this.sessionKey,
    required this.username,
    required this.role,
  });

  @override
  State<MaintenanceAdminPage> createState() => _MaintenanceAdminPageState();
}

class _MaintenanceAdminPageState extends State<MaintenanceAdminPage> {
  // ── Colors ─────────────────────────────────────────────────────────────────
  static const Color _bg = Color(0xFF0D1117);
  static const Color _surface = Color(0x14FFFFFF);
  static const Color _border = Color(0x1AFFFFFF);
  static const Color _accent = Color(0xFFFF6D00);
  static const Color _accentLight = Color(0xFFFF9100);
  static const Color _textPrimary = Color(0xFFE6EDF3);
  static const Color _textSecondary = Color(0xFF8B949E);

  // Semua role yang digunakan aplikasi (selain KINGZ yang selalu dikecualikan)
  static const List<String> _allRoles = [
    'OWNER',
    'TK',
    'PT',
    'RESELLER',
    'FULLUP',
    'member',
  ];

  final MaintenanceService _svc = MaintenanceService();

  // ── Local form state ───────────────────────────────────────────────────────
  bool _enabled = false;
  String _mode = 'text'; // 'text' | 'image' | 'image_text'
  final _titleCtrl = TextEditingController();
  final _msgCtrl = TextEditingController();
  String _imageUrl = '';
  String _targetMode = 'all'; // 'all' | 'selected_roles'
  final Set<String> _selectedRoles = {};

  bool _isSaving = false;
  bool _isUploading = false;
  String? _saveError;
  String? _saveSuccess;

  // For image preview before upload
  String? _localImagePath;

  bool _dirty = false; // form has unsaved changes

  @override
  void initState() {
    super.initState();
    // Guard – should never open if not KINGZ
    if (widget.role.toUpperCase() != 'KINGZ') {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        Navigator.pop(context);
      });
      return;
    }
    _loadFromService();
    _svc.addListener(_onServiceChange);
  }

  void _loadFromService() {
    final cfg = _svc.config;
    setState(() {
      _enabled = cfg.enabled;
      _mode = cfg.mode;
      _titleCtrl.text = cfg.title;
      _msgCtrl.text = cfg.message;
      _imageUrl = cfg.imageUrl;
      _targetMode = cfg.targetMode;
      _selectedRoles.clear();
      _selectedRoles.addAll(cfg.targetRoles);
      _dirty = false;
      _localImagePath = null;
    });
  }

  void _onServiceChange() {
    if (mounted && !_dirty) _loadFromService();
  }

  @override
  void dispose() {
    _svc.removeListener(_onServiceChange);
    _titleCtrl.dispose();
    _msgCtrl.dispose();
    super.dispose();
  }

  // ─── Upload gambar ke server ───────────────────────────────────────────────
  Future<void> _pickAndUploadImage() async {
    FilePickerResult? result = await FilePicker.platform.pickFiles(
      type: FileType.image,
      allowMultiple: false,
    );
    if (result == null || result.files.single.path == null) return;

    final localPath = result.files.single.path!;
    final fileSize = await File(localPath).length();

    // Batas 5 MB
    if (fileSize > 5 * 1024 * 1024) {
      _showSnack('Ukuran gambar melebihi batas 5 MB', Colors.redAccent);
      return;
    }

    setState(() {
      _isUploading = true;
      _localImagePath = localPath;
    });

    try {
      var request = http.MultipartRequest(
        'POST',
        Uri.parse('$baseUrl/api/upload'),
      );
      request.files.add(
        await http.MultipartFile.fromPath('image', localPath),
      );
      var response = await request.send();
      if (response.statusCode == 200) {
        final body = await response.stream.bytesToString();
        final json = jsonDecode(body);
        final url = json['url']?.toString() ?? '';
        if (url.isNotEmpty) {
          setState(() {
            _imageUrl = url;
            _dirty = true;
          });
          _showSnack('Gambar berhasil diunggah', Colors.green);
        } else {
          _showSnack('Upload berhasil tapi URL kosong', Colors.orange);
        }
      } else {
        _showSnack(
          'Upload gagal: status ${response.statusCode}',
          Colors.redAccent,
        );
      }
    } catch (e) {
      _showSnack('Upload error: $e', Colors.redAccent);
    } finally {
      setState(() => _isUploading = false);
    }
  }

  // ─── Simpan konfigurasi ───────────────────────────────────────────────────
  Future<void> _save() async {
    // Validasi
    if (_mode != 'image' && _titleCtrl.text.trim().isEmpty) {
      _showSnack('Judul tidak boleh kosong', Colors.orange);
      return;
    }
    if ((_mode == 'image' || _mode == 'image_text') && _imageUrl.isEmpty) {
      _showSnack('Pilih gambar terlebih dahulu', Colors.orange);
      return;
    }
    if (_mode == 'text' && _msgCtrl.text.trim().isEmpty) {
      _showSnack('Pesan tidak boleh kosong', Colors.orange);
      return;
    }
    if (_targetMode == 'selected_roles' && _selectedRoles.isEmpty) {
      _showSnack('Pilih minimal satu role target', Colors.orange);
      return;
    }

    // Konfirmasi toggle
    final bool toggling = _enabled != _svc.config.enabled;
    if (toggling) {
      final confirmed = await _showConfirmDialog(
        title: _enabled ? 'Aktifkan Maintenance?' : 'Nonaktifkan Maintenance?',
        body: _enabled
            ? 'Seluruh pengguna target akan diblokir dari aplikasi.'
            : 'Pengguna yang terdampak dapat menggunakan aplikasi kembali.',
      );
      if (!confirmed) return;
    }

    setState(() {
      _isSaving = true;
      _saveError = null;
      _saveSuccess = null;
    });

    final newCfg = MaintenanceConfig(
      enabled: _enabled,
      mode: _mode,
      title: _titleCtrl.text.trim(),
      message: _msgCtrl.text.trim(),
      imageUrl: _imageUrl,
      targetMode: _targetMode,
      targetRoles: _selectedRoles.toList(),
      updatedAt: '',
      updatedBy: '',
    );

    final err = await _svc.updateConfig(
      newCfg,
      updatedBy: widget.username,
      sessionKey: widget.sessionKey,
    );

    setState(() {
      _isSaving = false;
      if (err != null) {
        _saveError = err;
      } else {
        _saveSuccess = 'Konfigurasi berhasil disimpan';
        _dirty = false;
      }
    });
  }

  Future<bool> _showConfirmDialog({
    required String title,
    required String body,
  }) async {
    return await showDialog<bool>(
          context: context,
          builder: (ctx) => AlertDialog(
            backgroundColor: const Color(0xFF161B22),
            title: Text(title, style: const TextStyle(color: Colors.white)),
            content: Text(
              body,
              style: TextStyle(color: Colors.white.withOpacity(0.75)),
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(ctx, false),
                child: Text(
                  'Batal',
                  style: TextStyle(color: Colors.white.withOpacity(0.5)),
                ),
              ),
              ElevatedButton(
                onPressed: () => Navigator.pop(ctx, true),
                style: ElevatedButton.styleFrom(backgroundColor: _accent),
                child: const Text('Ya, Lanjutkan'),
              ),
            ],
          ),
        ) ??
        false;
  }

  void _showSnack(String msg, Color color) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(msg),
        backgroundColor: color,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      ),
    );
  }

  // ─── BUILD ────────────────────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _bg,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        title: ShaderMask(
          shaderCallback: (b) => const LinearGradient(
            colors: [Colors.white, Color(0xFFFF9100)],
          ).createShader(b),
          child: const Text(
            'Maintenance Mode',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w800,
              color: Colors.white,
              letterSpacing: 0.5,
            ),
          ),
        ),
        actions: [
          // Status badge
          Padding(
            padding: const EdgeInsets.only(right: 14),
            child: Center(
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: _svc.config.enabled
                      ? Colors.orange.withOpacity(0.18)
                      : Colors.green.withOpacity(0.18),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(
                    color: _svc.config.enabled
                        ? Colors.orange.withOpacity(0.5)
                        : Colors.green.withOpacity(0.5),
                    width: 0.8,
                  ),
                ),
                child: Text(
                  _svc.config.enabled ? 'AKTIF' : 'OFF',
                  style: TextStyle(
                    color:
                        _svc.config.enabled ? Colors.orange : Colors.greenAccent,
                    fontSize: 10,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 1,
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
      body: _isSaving
          ? const Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  CircularProgressIndicator(color: Color(0xFFFF6D00)),
                  SizedBox(height: 16),
                  Text('Menyimpan konfigurasi...',
                      style: TextStyle(color: Colors.white70)),
                ],
              ),
            )
          : SingleChildScrollView(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 100),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // ── Feedback ────────────────────────────────────────────
                  if (_saveError != null)
                    _FeedbackCard(
                      message: _saveError!,
                      color: Colors.redAccent,
                      icon: Icons.error_outline,
                    ),
                  if (_saveSuccess != null)
                    _FeedbackCard(
                      message: _saveSuccess!,
                      color: Colors.green,
                      icon: Icons.check_circle_outline,
                    ),

                  // ── Toggle Maintenance ─────────────────────────────────
                  _SectionCard(
                    title: 'Status Maintenance',
                    child: Row(
                      children: [
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                _enabled ? 'Maintenance AKTIF' : 'Maintenance OFF',
                                style: TextStyle(
                                  color: _enabled ? Colors.orange : Colors.green,
                                  fontWeight: FontWeight.w700,
                                  fontSize: 15,
                                ),
                              ),
                              const SizedBox(height: 4),
                              Text(
                                _enabled
                                    ? 'Pengguna target diblokir dari aplikasi'
                                    : 'Semua pengguna dapat mengakses aplikasi',
                                style: TextStyle(
                                  color: _textSecondary,
                                  fontSize: 12,
                                ),
                              ),
                            ],
                          ),
                        ),
                        Switch(
                          value: _enabled,
                          onChanged: (v) {
                            setState(() {
                              _enabled = v;
                              _dirty = true;
                              _saveError = null;
                              _saveSuccess = null;
                            });
                          },
                          activeColor: _accent,
                          activeTrackColor: _accent.withOpacity(0.3),
                        ),
                      ],
                    ),
                  ),

                  const SizedBox(height: 12),

                  // ── Mode pesan ─────────────────────────────────────────
                  _SectionCard(
                    title: 'Jenis Pesan',
                    child: Column(
                      children: [
                        _ModeOption(
                          value: 'text',
                          groupValue: _mode,
                          label: 'Teks Saja',
                          subtitle: 'Tampilkan judul & deskripsi',
                          icon: Icons.text_fields,
                          accent: _accent,
                          onChanged: (v) {
                            setState(() {
                              _mode = v!;
                              _dirty = true;
                            });
                          },
                        ),
                        _ModeOption(
                          value: 'image',
                          groupValue: _mode,
                          label: 'Gambar Saja',
                          subtitle: 'Tampilkan gambar tanpa teks',
                          icon: Icons.image,
                          accent: _accent,
                          onChanged: (v) {
                            setState(() {
                              _mode = v!;
                              _dirty = true;
                            });
                          },
                        ),
                        _ModeOption(
                          value: 'image_text',
                          groupValue: _mode,
                          label: 'Gambar + Teks',
                          subtitle: 'Tampilkan gambar, judul & deskripsi',
                          icon: Icons.photo_library,
                          accent: _accent,
                          onChanged: (v) {
                            setState(() {
                              _mode = v!;
                              _dirty = true;
                            });
                          },
                        ),
                      ],
                    ),
                  ),

                  const SizedBox(height: 12),

                  // ── Upload Gambar ──────────────────────────────────────
                  if (_mode == 'image' || _mode == 'image_text') ...[
                    _SectionCard(
                      title: 'Gambar Maintenance',
                      child: Column(
                        children: [
                          if (_isUploading)
                            const Padding(
                              padding: EdgeInsets.symmetric(vertical: 16),
                              child: Column(
                                children: [
                                  CircularProgressIndicator(
                                    color: Color(0xFFFF6D00),
                                  ),
                                  SizedBox(height: 10),
                                  Text(
                                    'Mengunggah gambar...',
                                    style: TextStyle(color: Colors.white60),
                                  ),
                                ],
                              ),
                            )
                          else if (_imageUrl.isNotEmpty) ...[
                            ClipRRect(
                              borderRadius: BorderRadius.circular(12),
                              child: Image.network(
                                _imageUrl,
                                height: 180,
                                width: double.infinity,
                                fit: BoxFit.cover,
                                errorBuilder: (_, __, ___) => Container(
                                  height: 180,
                                  color: Colors.white.withOpacity(0.04),
                                  child: const Center(
                                    child: Icon(
                                      Icons.broken_image,
                                      color: Colors.white38,
                                      size: 40,
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            const SizedBox(height: 10),
                            Row(
                              children: [
                                Expanded(
                                  child: OutlinedButton.icon(
                                    onPressed: _pickAndUploadImage,
                                    icon: const Icon(Icons.change_circle,
                                        color: Colors.orange, size: 16),
                                    label: const Text(
                                      'Ganti Gambar',
                                      style: TextStyle(color: Colors.orange),
                                    ),
                                    style: OutlinedButton.styleFrom(
                                      side: BorderSide(
                                        color: Colors.orange.withOpacity(0.4),
                                      ),
                                      shape: RoundedRectangleBorder(
                                        borderRadius: BorderRadius.circular(10),
                                      ),
                                    ),
                                  ),
                                ),
                                const SizedBox(width: 8),
                                OutlinedButton.icon(
                                  onPressed: () {
                                    setState(() {
                                      _imageUrl = '';
                                      _localImagePath = null;
                                      _dirty = true;
                                    });
                                  },
                                  icon: const Icon(Icons.delete_outline,
                                      color: Colors.redAccent, size: 16),
                                  label: const Text(
                                    'Hapus',
                                    style: TextStyle(color: Colors.redAccent),
                                  ),
                                  style: OutlinedButton.styleFrom(
                                    side: BorderSide(
                                      color: Colors.redAccent.withOpacity(0.4),
                                    ),
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(10),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ] else ...[
                            InkWell(
                              onTap: _pickAndUploadImage,
                              borderRadius: BorderRadius.circular(12),
                              child: Container(
                                height: 140,
                                width: double.infinity,
                                decoration: BoxDecoration(
                                  color: Colors.white.withOpacity(0.03),
                                  borderRadius: BorderRadius.circular(12),
                                  border: Border.all(
                                    color: _accent.withOpacity(0.3),
                                    width: 1.5,
                                    strokeAlign: BorderSide.strokeAlignInside,
                                  ),
                                ),
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Icon(
                                      Icons.add_photo_alternate_outlined,
                                      color: _accent.withOpacity(0.7),
                                      size: 36,
                                    ),
                                    const SizedBox(height: 8),
                                    Text(
                                      'Pilih Gambar dari Galeri',
                                      style: TextStyle(
                                        color: _accent,
                                        fontSize: 13,
                                        fontWeight: FontWeight.w600,
                                      ),
                                    ),
                                    const SizedBox(height: 4),
                                    Text(
                                      'Maks. 5 MB · JPG, PNG, WEBP',
                                      style: TextStyle(
                                        color: _textSecondary,
                                        fontSize: 11,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ],
                      ),
                    ),
                    const SizedBox(height: 12),
                  ],

                  // ── Teks Pesan ─────────────────────────────────────────
                  if (_mode == 'text' || _mode == 'image_text') ...[
                    _SectionCard(
                      title: 'Pesan Maintenance',
                      child: Column(
                        children: [
                          _InputField(
                            controller: _titleCtrl,
                            label: 'Judul',
                            hint: 'Aplikasi Sedang Dalam Pemeliharaan',
                            accent: _accent,
                            maxLines: 1,
                            onChanged: (_) => setState(() => _dirty = true),
                          ),
                          const SizedBox(height: 12),
                          _InputField(
                            controller: _msgCtrl,
                            label: 'Deskripsi',
                            hint:
                                'Kami sedang melakukan pemeliharaan sistem untuk meningkatkan kualitas layanan...',
                            accent: _accent,
                            maxLines: 4,
                            onChanged: (_) => setState(() => _dirty = true),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 12),
                  ],

                  // Jika mode 'image' – tetap tampilkan field judul (opsional)
                  if (_mode == 'image') ...[
                    _SectionCard(
                      title: 'Judul (Opsional)',
                      child: _InputField(
                        controller: _titleCtrl,
                        label: 'Judul',
                        hint: 'Opsional – biarkan kosong jika tidak diperlukan',
                        accent: _accent,
                        maxLines: 1,
                        onChanged: (_) => setState(() => _dirty = true),
                      ),
                    ),
                    const SizedBox(height: 12),
                  ],

                  // ── Target Role ────────────────────────────────────────
                  _SectionCard(
                    title: 'Target Pengguna',
                    child: Column(
                      children: [
                        _TargetOption(
                          value: 'all',
                          groupValue: _targetMode,
                          label: 'Semua Pengguna',
                          subtitle: 'Kecuali KINGZ',
                          accent: _accent,
                          onChanged: (v) => setState(() {
                            _targetMode = v!;
                            _dirty = true;
                          }),
                        ),
                        _TargetOption(
                          value: 'selected_roles',
                          groupValue: _targetMode,
                          label: 'Role Tertentu',
                          subtitle: 'Pilih role di bawah',
                          accent: _accent,
                          onChanged: (v) => setState(() {
                            _targetMode = v!;
                            _dirty = true;
                          }),
                        ),
                        if (_targetMode == 'selected_roles') ...[
                          const SizedBox(height: 10),
                          Wrap(
                            spacing: 8,
                            runSpacing: 6,
                            children: _allRoles.map((r) {
                              final selected = _selectedRoles.contains(r);
                              return FilterChip(
                                label: Text(
                                  r.toUpperCase(),
                                  style: TextStyle(
                                    color: selected ? Colors.white : _textSecondary,
                                    fontSize: 11,
                                    fontWeight: FontWeight.w700,
                                  ),
                                ),
                                selected: selected,
                                onSelected: (v) {
                                  setState(() {
                                    if (v) {
                                      _selectedRoles.add(r);
                                    } else {
                                      _selectedRoles.remove(r);
                                    }
                                    _dirty = true;
                                  });
                                },
                                backgroundColor: Colors.white.withOpacity(0.04),
                                selectedColor: _accent.withOpacity(0.25),
                                checkmarkColor: _accent,
                                side: BorderSide(
                                  color: selected
                                      ? _accent.withOpacity(0.6)
                                      : Colors.white.withOpacity(0.1),
                                  width: 0.8,
                                ),
                              );
                            }).toList(),
                          ),
                        ],
                      ],
                    ),
                  ),

                  const SizedBox(height: 12),

                  // ── Preview ────────────────────────────────────────────
                  _SectionCard(
                    title: 'Pratinjau',
                    child: _PreviewWidget(
                      mode: _mode,
                      title: _titleCtrl.text,
                      message: _msgCtrl.text,
                      imageUrl: _imageUrl,
                      accent: _accent,
                    ),
                  ),

                  const SizedBox(height: 20),

                  // ── Tombol Simpan ──────────────────────────────────────
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton.icon(
                      onPressed: _dirty ? _save : null,
                      icon: const Icon(Icons.save_rounded),
                      label: const Text(
                        'Simpan Konfigurasi',
                        style: TextStyle(
                          fontWeight: FontWeight.w700,
                          fontSize: 15,
                        ),
                      ),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: _accent,
                        disabledBackgroundColor: _accent.withOpacity(0.3),
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(vertical: 16),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(14),
                        ),
                      ),
                    ),
                  ),

                  if (!_dirty)
                    Padding(
                      padding: const EdgeInsets.only(top: 8),
                      child: Center(
                        child: Text(
                          'Tidak ada perubahan',
                          style: TextStyle(color: _textSecondary, fontSize: 12),
                        ),
                      ),
                    ),
                ],
              ),
            ),
    );
  }
}

// ─── HELPER WIDGETS ───────────────────────────────────────────────────────────

class _SectionCard extends StatelessWidget {
  final String title;
  final Widget child;

  const _SectionCard({required this.title, required this.child});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0x14FFFFFF),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0x1AFFFFFF), width: 0.8),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title.toUpperCase(),
            style: const TextStyle(
              color: Color(0xFF8B949E),
              fontSize: 10,
              fontWeight: FontWeight.w700,
              letterSpacing: 1.5,
            ),
          ),
          const SizedBox(height: 14),
          child,
        ],
      ),
    );
  }
}

class _ModeOption extends StatelessWidget {
  final String value;
  final String groupValue;
  final String label;
  final String subtitle;
  final IconData icon;
  final Color accent;
  final ValueChanged<String?> onChanged;

  const _ModeOption({
    required this.value,
    required this.groupValue,
    required this.label,
    required this.subtitle,
    required this.icon,
    required this.accent,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    final selected = value == groupValue;
    return Padding(
      padding: const EdgeInsets.only(bottom: 6),
      child: InkWell(
        onTap: () => onChanged(value),
        borderRadius: BorderRadius.circular(12),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
          decoration: BoxDecoration(
            color: selected
                ? accent.withOpacity(0.1)
                : Colors.white.withOpacity(0.03),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(
              color: selected
                  ? accent.withOpacity(0.5)
                  : Colors.white.withOpacity(0.06),
              width: 0.8,
            ),
          ),
          child: Row(
            children: [
              Icon(icon, color: selected ? accent : Colors.white38, size: 20),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      label,
                      style: TextStyle(
                        color: selected ? Colors.white : Colors.white70,
                        fontWeight: FontWeight.w600,
                        fontSize: 13,
                      ),
                    ),
                    Text(
                      subtitle,
                      style: const TextStyle(
                        color: Color(0xFF8B949E),
                        fontSize: 11,
                      ),
                    ),
                  ],
                ),
              ),
              Radio<String>(
                value: value,
                groupValue: groupValue,
                onChanged: onChanged,
                activeColor: accent,
                materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _TargetOption extends StatelessWidget {
  final String value;
  final String groupValue;
  final String label;
  final String subtitle;
  final Color accent;
  final ValueChanged<String?> onChanged;

  const _TargetOption({
    required this.value,
    required this.groupValue,
    required this.label,
    required this.subtitle,
    required this.accent,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    final selected = value == groupValue;
    return Padding(
      padding: const EdgeInsets.only(bottom: 6),
      child: InkWell(
        onTap: () => onChanged(value),
        borderRadius: BorderRadius.circular(12),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
          decoration: BoxDecoration(
            color: selected
                ? accent.withOpacity(0.1)
                : Colors.white.withOpacity(0.03),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(
              color: selected
                  ? accent.withOpacity(0.5)
                  : Colors.white.withOpacity(0.06),
              width: 0.8,
            ),
          ),
          child: Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      label,
                      style: TextStyle(
                        color: selected ? Colors.white : Colors.white70,
                        fontWeight: FontWeight.w600,
                        fontSize: 13,
                      ),
                    ),
                    Text(
                      subtitle,
                      style: const TextStyle(
                        color: Color(0xFF8B949E),
                        fontSize: 11,
                      ),
                    ),
                  ],
                ),
              ),
              Radio<String>(
                value: value,
                groupValue: groupValue,
                onChanged: onChanged,
                activeColor: accent,
                materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _InputField extends StatelessWidget {
  final TextEditingController controller;
  final String label;
  final String hint;
  final Color accent;
  final int maxLines;
  final ValueChanged<String>? onChanged;

  const _InputField({
    required this.controller,
    required this.label,
    required this.hint,
    required this.accent,
    this.maxLines = 1,
    this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    return TextField(
      controller: controller,
      maxLines: maxLines,
      onChanged: onChanged,
      style: const TextStyle(color: Colors.white, fontSize: 14),
      decoration: InputDecoration(
        labelText: label,
        hintText: hint,
        labelStyle: TextStyle(color: accent.withOpacity(0.8), fontSize: 12),
        hintStyle: const TextStyle(color: Color(0xFF8B949E), fontSize: 13),
        filled: true,
        fillColor: Colors.white.withOpacity(0.04),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide:
              BorderSide(color: Colors.white.withOpacity(0.1), width: 0.8),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide(color: accent.withOpacity(0.6), width: 1),
        ),
      ),
    );
  }
}

class _FeedbackCard extends StatelessWidget {
  final String message;
  final Color color;
  final IconData icon;

  const _FeedbackCard({
    required this.message,
    required this.color,
    required this.icon,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: color.withOpacity(0.3), width: 0.8),
      ),
      child: Row(
        children: [
          Icon(icon, color: color, size: 18),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              message,
              style: TextStyle(color: color, fontSize: 13),
            ),
          ),
        ],
      ),
    );
  }
}

class _PreviewWidget extends StatelessWidget {
  final String mode;
  final String title;
  final String message;
  final String imageUrl;
  final Color accent;

  const _PreviewWidget({
    required this.mode,
    required this.title,
    required this.message,
    required this.imageUrl,
    required this.accent,
  });

  @override
  Widget build(BuildContext context) {
    final bool showImage =
        (mode == 'image' || mode == 'image_text') && imageUrl.isNotEmpty;
    final bool showText = mode == 'text' || mode == 'image_text';

    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: const Color(0xFF0D1117),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: Colors.white.withOpacity(0.06),
          width: 0.8,
        ),
      ),
      child: Column(
        children: [
          Container(
            width: 8,
            height: 8,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: Colors.orange,
              boxShadow: [
                BoxShadow(
                  color: Colors.orange.withOpacity(0.6),
                  blurRadius: 6,
                  spreadRadius: 1,
                ),
              ],
            ),
          ),
          const SizedBox(height: 10),
          if (showImage && imageUrl.isNotEmpty)
            ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: Image.network(
                imageUrl,
                height: 100,
                width: double.infinity,
                fit: BoxFit.cover,
                errorBuilder: (_, __, ___) => Container(
                  height: 100,
                  color: Colors.white.withOpacity(0.04),
                  child: const Center(
                    child: Icon(
                      Icons.image_not_supported,
                      color: Colors.white24,
                    ),
                  ),
                ),
              ),
            )
          else
            Icon(Icons.build_rounded, color: accent.withOpacity(0.6), size: 30),
          if (showText && title.isNotEmpty) ...[
            const SizedBox(height: 8),
            Text(
              title,
              textAlign: TextAlign.center,
              style: const TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.w700,
                fontSize: 13,
              ),
            ),
          ],
          if (showText && message.isNotEmpty) ...[
            const SizedBox(height: 4),
            Text(
              message,
              textAlign: TextAlign.center,
              maxLines: 3,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                color: Colors.white.withOpacity(0.6),
                fontSize: 11,
              ),
            ),
          ],
          if (!showImage && !showText || (title.isEmpty && message.isEmpty && imageUrl.isEmpty))
            Text(
              'Pratinjau akan muncul setelah Anda mengisi konten',
              textAlign: TextAlign.center,
              style: TextStyle(
                color: Colors.white.withOpacity(0.3),
                fontSize: 11,
              ),
            ),
        ],
      ),
    );
  }
}
