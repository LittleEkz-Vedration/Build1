import 'dart:async';
import 'package:firebase_database/firebase_database.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

// ─── CONSTANTS ────────────────────────────────────────────────────────────────
const String _kDbUrl =
    'https://dentmvn1-default-rtdb.asia-southeast1.firebasedatabase.app/';
const String _kMaintenancePath = 'maintenance_config';

// ─── MODEL ────────────────────────────────────────────────────────────────────
class MaintenanceConfig {
  final bool enabled;
  final String mode; // 'text', 'image', 'image_text'
  final String title;
  final String message;
  final String imageUrl;
  final String targetMode; // 'all' or 'selected_roles'
  final List<String> targetRoles;
  final String updatedAt;
  final String updatedBy;

  const MaintenanceConfig({
    required this.enabled,
    required this.mode,
    required this.title,
    required this.message,
    required this.imageUrl,
    required this.targetMode,
    required this.targetRoles,
    required this.updatedAt,
    required this.updatedBy,
  });

  factory MaintenanceConfig.fromMap(Map<dynamic, dynamic> map) {
    return MaintenanceConfig(
      enabled: map['enabled'] == true,
      mode: (map['mode'] ?? 'text').toString(),
      title: (map['title'] ?? '').toString(),
      message: (map['message'] ?? '').toString(),
      imageUrl: (map['imageUrl'] ?? '').toString(),
      targetMode: (map['targetMode'] ?? 'all').toString(),
      targetRoles: _parseRoles(map['targetRoles']),
      updatedAt: (map['updatedAt'] ?? '').toString(),
      updatedBy: (map['updatedBy'] ?? '').toString(),
    );
  }

  static List<String> _parseRoles(dynamic raw) {
    if (raw == null) return [];
    if (raw is List) return raw.map((e) => e.toString()).toList();
    if (raw is Map) return raw.values.map((e) => e.toString()).toList();
    return [];
  }

  Map<String, dynamic> toMap() => {
    'enabled': enabled,
    'mode': mode,
    'title': title,
    'message': message,
    'imageUrl': imageUrl,
    'targetMode': targetMode,
    'targetRoles': targetRoles,
    'updatedAt': updatedAt,
    'updatedBy': updatedBy,
  };

  MaintenanceConfig copyWith({
    bool? enabled,
    String? mode,
    String? title,
    String? message,
    String? imageUrl,
    String? targetMode,
    List<String>? targetRoles,
    String? updatedAt,
    String? updatedBy,
  }) =>
      MaintenanceConfig(
        enabled: enabled ?? this.enabled,
        mode: mode ?? this.mode,
        title: title ?? this.title,
        message: message ?? this.message,
        imageUrl: imageUrl ?? this.imageUrl,
        targetMode: targetMode ?? this.targetMode,
        targetRoles: targetRoles ?? this.targetRoles,
        updatedAt: updatedAt ?? this.updatedAt,
        updatedBy: updatedBy ?? this.updatedBy,
      );

  static MaintenanceConfig get defaultConfig => const MaintenanceConfig(
    enabled: false,
    mode: 'text',
    title: 'Aplikasi Sedang Dalam Pemeliharaan',
    message:
        'Kami sedang melakukan pemeliharaan sistem untuk meningkatkan kualitas layanan. '
        'Silakan kembali beberapa saat lagi. Terima kasih atas pengertiannya.',
    imageUrl: '',
    targetMode: 'all',
    targetRoles: [],
    updatedAt: '',
    updatedBy: '',
  );
}

// ─── SERVICE ─────────────────────────────────────────────────────────────────
class MaintenanceService extends ChangeNotifier {
  // Singleton
  static final MaintenanceService _instance = MaintenanceService._internal();
  factory MaintenanceService() => _instance;
  MaintenanceService._internal();

  // ── State ──
  MaintenanceConfig _config = MaintenanceConfig.defaultConfig;
  bool _isLoading = false;
  String? _error;
  StreamSubscription<DatabaseEvent>? _subscription;
  bool _initialized = false;

  // ── Public getters ──
  MaintenanceConfig get config => _config;
  bool get isLoading => _isLoading;
  String? get error => _error;
  bool get initialized => _initialized;

  // ── Firebase ref ──
  DatabaseReference get _ref {
    final fb = FirebaseDatabase.instanceFor(
      app: Firebase.app(),
      databaseURL: _kDbUrl,
    );
    return fb.ref(_kMaintenancePath);
  }

  // ─── Determine if a given role is blocked by current config ──────────────
  bool isRoleBlocked(String role) {
    if (!_config.enabled) return false;
    // KINGZ is never blocked
    if (role.toUpperCase() == 'KINGZ') return false;
    if (_config.targetMode == 'all') return true;
    // selected_roles
    return _config.targetRoles
        .any((r) => r.toLowerCase() == role.toLowerCase());
  }

  // ─── Start real-time listener ─────────────────────────────────────────────
  void startListening() {
    if (_subscription != null) return; // already listening
    try {
      _subscription = _ref.onValue.listen(
        (event) {
          final raw = event.snapshot.value;
          if (raw != null && raw is Map) {
            _config = MaintenanceConfig.fromMap(raw);
          } else {
            _config = MaintenanceConfig.defaultConfig;
          }
          _initialized = true;
          _error = null;
          notifyListeners();
        },
        onError: (e) {
          _error = e.toString();
          _initialized = true;
          notifyListeners();
          debugPrint('[Maintenance] Listener error: $e');
        },
      );
    } catch (e) {
      _error = e.toString();
      _initialized = true;
      notifyListeners();
      debugPrint('[Maintenance] startListening exception: $e');
    }
  }

  // ─── Stop listener ────────────────────────────────────────────────────────
  void stopListening() {
    _subscription?.cancel();
    _subscription = null;
  }

  // ─── Fetch once (for retry button) ───────────────────────────────────────
  Future<void> fetchOnce() async {
    _isLoading = true;
    _error = null;
    notifyListeners();
    try {
      final snap = await _ref.get();
      final raw = snap.value;
      if (raw != null && raw is Map) {
        _config = MaintenanceConfig.fromMap(raw);
      } else {
        _config = MaintenanceConfig.defaultConfig;
      }
      _initialized = true;
    } catch (e) {
      _error = e.toString();
      _initialized = true;
      debugPrint('[Maintenance] fetchOnce error: $e');
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  // ─── Update config (KINGZ only – server-side rule enforces this) ──────────
  Future<String?> updateConfig(
    MaintenanceConfig newConfig, {
    required String updatedBy,
    required String sessionKey,
  }) async {
    // Basic client-side guard
    if (sessionKey.isEmpty) return 'Session tidak valid';

    _isLoading = true;
    notifyListeners();

    try {
      final now = DateTime.now().toIso8601String();
      final updated = newConfig.copyWith(
        updatedAt: now,
        updatedBy: updatedBy,
      );
      await _ref.set(updated.toMap());
      _config = updated;
      _error = null;
      return null; // success
    } catch (e) {
      _error = e.toString();
      debugPrint('[Maintenance] updateConfig error: $e');
      return 'Gagal menyimpan: ${e.toString()}';
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  /// Toggle only the enabled flag
  Future<String?> toggleEnabled({
    required bool newValue,
    required String updatedBy,
    required String sessionKey,
  }) async {
    if (sessionKey.isEmpty) return 'Session tidak valid';
    _isLoading = true;
    notifyListeners();
    try {
      await _ref.update({
        'enabled': newValue,
        'updatedAt': DateTime.now().toIso8601String(),
        'updatedBy': updatedBy,
      });
      _config = _config.copyWith(
        enabled: newValue,
        updatedAt: DateTime.now().toIso8601String(),
        updatedBy: updatedBy,
      );
      _error = null;
      return null;
    } catch (e) {
      _error = e.toString();
      return 'Gagal: ${e.toString()}';
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  @override
  void dispose() {
    stopListening();
    super.dispose();
  }
}
