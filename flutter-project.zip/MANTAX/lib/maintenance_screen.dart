import 'dart:ui';
import 'package:flutter/material.dart';
import 'maintenance_service.dart';

/// Halaman yang ditampilkan ke pengguna yang sedang kena maintenance.
/// Pengguna tidak bisa keluar dari halaman ini selama maintenance aktif
/// dan role mereka termasuk target.
class MaintenanceScreen extends StatefulWidget {
  final MaintenanceService service;
  final VoidCallback? onMaintenanceLifted; // dipanggil saat maintenance nonaktif

  const MaintenanceScreen({
    super.key,
    required this.service,
    this.onMaintenanceLifted,
  });

  @override
  State<MaintenanceScreen> createState() => _MaintenanceScreenState();
}

class _MaintenanceScreenState extends State<MaintenanceScreen>
    with TickerProviderStateMixin {
  late AnimationController _pulseController;
  late Animation<double> _pulseAnim;

  @override
  void initState() {
    super.initState();
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    )..repeat(reverse: true);

    _pulseAnim = Tween<double>(begin: 0.85, end: 1.0).animate(
      CurvedAnimation(parent: _pulseController, curve: Curves.easeInOut),
    );

    widget.service.addListener(_onConfigChanged);
  }

  void _onConfigChanged() {
    // Jika maintenance dinonaktifkan atau role sudah tidak kena → callback
    if (!widget.service.config.enabled) {
      widget.onMaintenanceLifted?.call();
    }
  }

  @override
  void dispose() {
    widget.service.removeListener(_onConfigChanged);
    _pulseController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final cfg = widget.service.config;
    final bool hasImage =
        cfg.imageUrl.isNotEmpty &&
        (cfg.mode == 'image' || cfg.mode == 'image_text');
    final bool hasText =
        cfg.mode == 'text' || cfg.mode == 'image_text';

    return Scaffold(
      backgroundColor: const Color(0xFF0D1117),
      body: SafeArea(
        child: Column(
          children: [
            // ── Top status bar ──────────────────────────────────────────────
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
              decoration: BoxDecoration(
                color: Colors.orange.withOpacity(0.08),
                border: Border(
                  bottom: BorderSide(
                    color: Colors.orange.withOpacity(0.2),
                    width: 0.8,
                  ),
                ),
              ),
              child: Row(
                children: [
                  ScaleTransition(
                    scale: _pulseAnim,
                    child: Container(
                      width: 10,
                      height: 10,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: Colors.orange,
                        boxShadow: [
                          BoxShadow(
                            color: Colors.orange.withOpacity(0.7),
                            blurRadius: 8,
                            spreadRadius: 2,
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Text(
                    'SISTEM DALAM MAINTENANCE',
                    style: TextStyle(
                      color: Colors.orange.withOpacity(0.9),
                      fontSize: 11,
                      fontWeight: FontWeight.w700,
                      letterSpacing: 1.5,
                    ),
                  ),
                ],
              ),
            ),

            // ── Content ─────────────────────────────────────────────────────
            Expanded(
              child: widget.service.isLoading
                  ? const Center(
                      child: CircularProgressIndicator(color: Colors.orange),
                    )
                  : SingleChildScrollView(
                      padding: const EdgeInsets.all(24),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          const SizedBox(height: 20),

                          // ── Icon / Gambar ──────────────────────────────
                          if (hasImage) ...[
                            ClipRRect(
                              borderRadius: BorderRadius.circular(20),
                              child: Image.network(
                                cfg.imageUrl,
                                width: double.infinity,
                                fit: BoxFit.contain,
                                errorBuilder: (_, __, ___) => _buildIconWidget(),
                              ),
                            ),
                            const SizedBox(height: 28),
                          ] else
                            _buildIconWidget(),

                          const SizedBox(height: 28),

                          // ── Judul ──────────────────────────────────────
                          if (hasText || cfg.title.isNotEmpty) ...[
                            Text(
                              cfg.title.isNotEmpty
                                  ? cfg.title
                                  : 'Aplikasi Sedang Dalam Pemeliharaan',
                              textAlign: TextAlign.center,
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 22,
                                fontWeight: FontWeight.w800,
                                letterSpacing: 0.5,
                              ),
                            ),
                            const SizedBox(height: 16),
                          ],

                          // ── Deskripsi ──────────────────────────────────
                          if (hasText && cfg.message.isNotEmpty) ...[
                            Container(
                              padding: const EdgeInsets.all(18),
                              decoration: BoxDecoration(
                                color: Colors.white.withOpacity(0.04),
                                borderRadius: BorderRadius.circular(16),
                                border: Border.all(
                                  color: Colors.white.withOpacity(0.08),
                                  width: 0.8,
                                ),
                              ),
                              child: Text(
                                cfg.message,
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                  color: Colors.white.withOpacity(0.75),
                                  fontSize: 14,
                                  height: 1.6,
                                ),
                              ),
                            ),
                            const SizedBox(height: 24),
                          ],

                          // ── Updated at ─────────────────────────────────
                          if (cfg.updatedAt.isNotEmpty) ...[
                            Text(
                              'Terakhir diperbarui: ${_formatDate(cfg.updatedAt)}',
                              style: TextStyle(
                                color: Colors.white.withOpacity(0.35),
                                fontSize: 11,
                              ),
                            ),
                            const SizedBox(height: 24),
                          ],

                          // ── Tombol Coba Lagi ───────────────────────────
                          SizedBox(
                            width: double.infinity,
                            child: OutlinedButton.icon(
                              onPressed: () => widget.service.fetchOnce(),
                              icon: const Icon(
                                Icons.refresh,
                                color: Colors.orange,
                                size: 18,
                              ),
                              label: const Text(
                                'Coba Lagi',
                                style: TextStyle(
                                  color: Colors.orange,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                              style: OutlinedButton.styleFrom(
                                side: BorderSide(
                                  color: Colors.orange.withOpacity(0.5),
                                ),
                                padding: const EdgeInsets.symmetric(vertical: 14),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(14),
                                ),
                              ),
                            ),
                          ),

                          if (widget.service.error != null) ...[
                            const SizedBox(height: 12),
                            Text(
                              'Koneksi gagal – menampilkan status terakhir',
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                color: Colors.redAccent.withOpacity(0.7),
                                fontSize: 11,
                              ),
                            ),
                          ],

                          const SizedBox(height: 32),
                        ],
                      ),
                    ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildIconWidget() {
    return ScaleTransition(
      scale: _pulseAnim,
      child: Container(
        width: 100,
        height: 100,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: Colors.orange.withOpacity(0.12),
          border: Border.all(
            color: Colors.orange.withOpacity(0.3),
            width: 2,
          ),
        ),
        child: const Icon(
          Icons.build_rounded,
          color: Colors.orange,
          size: 44,
        ),
      ),
    );
  }

  String _formatDate(String iso) {
    try {
      final dt = DateTime.parse(iso).toLocal();
      return '${dt.day.toString().padLeft(2, '0')}/'
          '${dt.month.toString().padLeft(2, '0')}/'
          '${dt.year} '
          '${dt.hour.toString().padLeft(2, '0')}:'
          '${dt.minute.toString().padLeft(2, '0')}';
    } catch (_) {
      return iso;
    }
  }
}
