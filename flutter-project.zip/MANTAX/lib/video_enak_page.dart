import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';

/// Daftar domain iklan yang umum diblokir.
const List<String> _blockedAdDomains = [
  'googlesyndication.com',
  'doubleclick.net',
  'googleadservices.com',
  'adservice.google.com',
  'ads.google.com',
  'pagead2.googlesyndication.com',
  'adnxs.com',
  'adsrvr.org',
  'advertising.com',
  'amazon-adsystem.com',
  'outbrain.com',
  'taboola.com',
  'revcontent.com',
  'popads.net',
  'popcash.net',
  'propellerads.com',
  'trafficjunky.net',
  'juicyads.com',
  'exoclick.com',
  'hilltopads.net',
  'adspyglass.com',
  'adsterra.com',
  'ero-advertising.com',
  'trafficstars.com',
  'plugrush.com',
  'clickadu.com',
  'pushground.com',
  'zeropark.com',
];

bool _isAdDomain(String url) {
  try {
    final uri = Uri.tryParse(url);
    if (uri == null) return false;
    final host = uri.host.toLowerCase();
    for (final domain in _blockedAdDomains) {
      if (host == domain || host.endsWith('.$domain')) {
        return true;
      }
    }
  } catch (_) {}
  return false;
}

class VideoEnakPage extends StatefulWidget {
  const VideoEnakPage({Key? key}) : super(key: key);

  @override
  State<VideoEnakPage> createState() => _VideoEnakPageState();
}

class _VideoEnakPageState extends State<VideoEnakPage> {
  late final WebViewController _controller;
  bool _isLoading = true;
  bool _hasError = false;
  String _errorMessage = '';
  int _loadingProgress = 0;

  static const String _targetUrl = 'https://asupanrare.com';

  @override
  void initState() {
    super.initState();
    _initWebView();
  }

  void _initWebView() {
    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(Colors.black)
      ..setUserAgent(
        'Mozilla/5.0 (Linux; Android 13; Pixel 7) '
        'AppleWebKit/537.36 (KHTML, like Gecko) '
        'Chrome/120.0.0.0 Mobile Safari/537.36',
      )
      ..setNavigationDelegate(
        NavigationDelegate(
          onPageStarted: (url) {
            if (mounted) {
              setState(() {
                _isLoading = true;
                _hasError = false;
                _loadingProgress = 0;
              });
            }
          },
          onProgress: (progress) {
            if (mounted) {
              setState(() => _loadingProgress = progress);
            }
          },
          onPageFinished: (url) {
            if (mounted) {
              setState(() {
                _isLoading = false;
                _loadingProgress = 100;
              });
            }
            _injectAdHider();
          },
          onWebResourceError: (error) {
            if (mounted && error.isForMainFrame == true) {
              setState(() {
                _isLoading = false;
                _hasError = true;
                _errorMessage = _friendlyError(error.errorCode);
              });
            }
          },
          onNavigationRequest: (request) {
            if (_isAdDomain(request.url)) {
              return NavigationDecision.prevent;
            }
            return NavigationDecision.navigate;
          },
        ),
      )
      ..loadRequest(Uri.parse(_targetUrl));
  }

  void _injectAdHider() {
    const js = r'''
      (function() {
        try {
          var style = document.createElement('style');
          style.type = 'text/css';
          style.innerHTML = `
            [id*="advert" i], [class*="advert" i],
            [id*="banner-ad" i], [class*="banner-ad" i],
            [id*="ad-banner" i], [class*="ad-banner" i],
            [id*="popup-ad" i], [class*="popup-ad" i],
            [id*="overlay-ad" i], [class*="overlay-ad" i],
            ins.adsbygoogle,
            iframe[src*="googlesyndication"],
            iframe[src*="doubleclick"],
            iframe[src*="adnxs"],
            iframe[src*="exoclick"],
            iframe[src*="trafficjunky"],
            iframe[src*="juicyads"] {
              display: none !important;
              visibility: hidden !important;
              pointer-events: none !important;
            }
          `;
          document.head.appendChild(style);
        } catch(e) {}
      })();
    ''';
    _controller.runJavaScript(js).catchError((_) {});
  }

  String _friendlyError(int? code) {
    switch (code) {
      case -2:
        return 'Tidak ada koneksi internet.\nPeriksa koneksi Anda lalu coba lagi.';
      case -6:
        return 'Koneksi ke server gagal.\nCoba lagi beberapa saat.';
      case -8:
        return 'Waktu koneksi habis.\nPeriksa koneksi internet Anda.';
      default:
        return 'Gagal memuat halaman.\nKode: ${code ?? "tidak diketahui"}';
    }
  }

  Future<bool> _onWillPop() async {
    if (await _controller.canGoBack()) {
      await _controller.goBack();
      return false;
    }
    return true;
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: _onWillPop,
      child: Scaffold(
        backgroundColor: Colors.black,
        appBar: AppBar(
          backgroundColor: Colors.black,
          elevation: 0,
          leading: IconButton(
            icon: const Icon(Icons.arrow_back_ios_new_rounded, color: Colors.white),
            onPressed: () async {
              if (await _controller.canGoBack()) {
                _controller.goBack();
              } else {
                if (context.mounted) Navigator.of(context).pop();
              }
            },
          ),
          title: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(6),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [Color(0xFFE91E63), Color(0xFF9C27B0)],
                  ),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: const Icon(
                  Icons.play_circle_filled_rounded,
                  color: Colors.white,
                  size: 18,
                ),
              ),
              const SizedBox(width: 10),
              const Text(
                'VIDEO ENAK',
                style: TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.w800,
                  fontSize: 18,
                  letterSpacing: 1.2,
                ),
              ),
            ],
          ),
          actions: [
            IconButton(
              icon: const Icon(Icons.refresh_rounded, color: Colors.white70),
              onPressed: () {
                setState(() {
                  _hasError = false;
                  _isLoading = true;
                });
                _controller.reload();
              },
            ),
          ],
          bottom: _isLoading && _loadingProgress > 0 && _loadingProgress < 100
              ? PreferredSize(
                  preferredSize: const Size.fromHeight(3),
                  child: LinearProgressIndicator(
                    value: _loadingProgress / 100,
                    backgroundColor: Colors.white12,
                    valueColor: const AlwaysStoppedAnimation<Color>(Color(0xFFE91E63)),
                    minHeight: 3,
                  ),
                )
              : null,
        ),
        body: _hasError ? _buildErrorView() : _buildWebView(),
      ),
    );
  }

  Widget _buildWebView() {
    return Stack(
      children: [
        WebViewWidget(controller: _controller),
        if (_isLoading && _loadingProgress == 0)
          Container(
            color: Colors.black,
            child: const Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  CircularProgressIndicator(
                    valueColor: AlwaysStoppedAnimation<Color>(Color(0xFFE91E63)),
                  ),
                  SizedBox(height: 20),
                  Text(
                    'Memuat VIDEO ENAK...',
                    style: TextStyle(
                      color: Colors.white70,
                      fontSize: 16,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ],
              ),
            ),
          ),
      ],
    );
  }

  Widget _buildErrorView() {
    return Container(
      color: Colors.black,
      child: Center(
        child: Padding(
          padding: const EdgeInsets.all(32),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                padding: const EdgeInsets.all(24),
                decoration: BoxDecoration(
                  color: const Color(0xFFE91E63).withOpacity(0.1),
                  shape: BoxShape.circle,
                  border: Border.all(
                    color: const Color(0xFFE91E63).withOpacity(0.3),
                    width: 2,
                  ),
                ),
                child: const Icon(
                  Icons.wifi_off_rounded,
                  color: Color(0xFFE91E63),
                  size: 52,
                ),
              ),
              const SizedBox(height: 28),
              Text(
                _errorMessage,
                textAlign: TextAlign.center,
                style: const TextStyle(
                  color: Colors.white70,
                  fontSize: 15,
                  height: 1.6,
                ),
              ),
              const SizedBox(height: 32),
              ElevatedButton.icon(
                onPressed: () {
                  setState(() {
                    _hasError = false;
                    _isLoading = true;
                  });
                  _controller.loadRequest(Uri.parse(_targetUrl));
                },
                icon: const Icon(Icons.refresh_rounded),
                label: const Text(
                  'COBA LAGI',
                  style: TextStyle(fontWeight: FontWeight.bold, letterSpacing: 1),
                ),
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFFE91E63),
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 14),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(14),
                  ),
                  elevation: 6,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  void dispose() {
    super.dispose();
  }
}
