import fs from 'fs'
import archiver from 'archiver'
import path from 'path'

let handler = async (m, { conn }) => {
  try {
    const root = process.cwd()

    await conn.reply(
      m.chat,
      '⏳ Sedang membuat backup...',
      m
    )

    let target =
      m.mentionedJid?.[0] ||
      m.quoted?.sender ||
      m.sender

    const backupName = `Anya-MD-${Date.now()}.zip`
    const backupPath = path.join(root, backupName)

    const output = fs.createWriteStream(backupPath)
    const archive = archiver('zip', {
      zlib: { level: 9 }
    })

    archive.pipe(output)

    archive.glob('**/*', {
      cwd: root,
      ignore: [
        'node_modules/**',
        'sessions/**',
        '.git/**',
        'tmp/**',
        backupName
      ]
    })

    await archive.finalize()

    output.on('close', async () => {
      try {
        const size = (
          archive.pointer() /
          1024 /
          1024
        ).toFixed(2)

        const caption = `
📦 *BACKUP BERHASIL*

📁 File: ${backupName}
📦 Size: ${size} MB
        `.trim()

        // kirim langsung ke private chat target
        await conn.sendMessage(target, {
          document: fs.readFileSync(backupPath),
          mimetype: 'application/zip',
          fileName: backupName,
          caption
        })

        await conn.reply(
          m.chat,
          `✅ Backup berhasil dikirim ke private chat @${target.split('@')[0]}`,
          m,
          {
            mentions: [target]
          }
        )

        fs.unlinkSync(backupPath)
      } catch (e) {
        if (fs.existsSync(backupPath))
          fs.unlinkSync(backupPath)

        await conn.reply(
          m.chat,
          `❌ Gagal mengirim backup\n${e.message}`,
          m
        )
      }
    })

  } catch (e) {
    await conn.reply(
      m.chat,
      `❌ Backup gagal\n${e.message}`,
      m
    )
  }
}

handler.help = ['backup', 'backup @tag']
handler.tags = ['owner']
handler.command = /^backup$/i
handler.owner = true

export default handler